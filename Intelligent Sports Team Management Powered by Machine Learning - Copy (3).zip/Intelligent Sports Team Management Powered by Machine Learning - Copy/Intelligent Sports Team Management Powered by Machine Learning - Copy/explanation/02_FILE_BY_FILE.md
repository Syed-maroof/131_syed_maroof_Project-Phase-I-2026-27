# 02 — Every File Explained

This document explains every single file in the project —
what it does, why it exists, and what the key parts mean.

---

## datasets/ — Raw Data Files

### `datasets/football_players.csv`
Contains 18 Indian football players with columns:
- `Player_ID` — unique code (e.g. FB001)
- `Player_Name` — full name
- `Age` — player age
- `Position` — Goalkeeper / Defender / Midfielder / Winger / Forward
- `Matches` — number of matches played
- `Goals`, `Assists` — attacking stats
- `Pass_Accuracy` — % of passes that reached a teammate
- `Tackles`, `Interceptions` — defensive stats
- `Shots` — total shots taken
- `Fitness_Score` — physical condition (0–100)
- `Recent_Form` — form in last 5 games (0–100)
- `Injury_Count` — number of recent injuries
- `Performance_Score` — the TARGET column the ML model tries to predict

### `datasets/cricket_players.csv`
Contains 18 Indian cricket players with columns:
- `Role` — Batsman / Bowler / All-Rounder / Wicketkeeper-Batsman
- `Runs`, `Batting_Average`, `Strike_Rate` — batting stats
- `Fifties`, `Centuries` — milestone innings
- `Wickets`, `Economy`, `Bowling_Average` — bowling stats
- `Catches` — fielding stat
- *(same common columns as football)*

### `datasets/volleyball_players.csv`
Contains 12 Indian volleyball players with columns:
- `Position` — Setter / Outside Hitter / Opposite / Middle Blocker / Libero
- `Attack_Points`, `Attack_Accuracy` — offensive stats
- `Aces` — serve aces scored
- `Blocks` — blocks made
- `Digs` — defensive saves
- `Assists` — setting assists
- *(same common columns as football)*

---

## src/ — Machine Learning Code

### `src/preprocess.py`
**What it does:** Cleans and prepares player data for the ML model.

Key functions:
- `preprocess_football()` — cleans football CSV, creates new features, scales data
- `preprocess_cricket()` — same for cricket
- `preprocess_volleyball()` — same for volleyball
- `preprocess_all()` — runs all three at once

What happens inside:
```
1. Load the CSV file
2. Remove rows with missing values
3. Clip outlier values (IQR method)
4. Create new calculated columns:
   - Goals_per_Match = Goals / Matches
   - Availability_Score = Fitness - (Injury * 3)
   - etc.
5. Scale all numbers to 0–1 range (MinMaxScaler)
6. Save the scaler to model/scaler_sport.pkl
```

---

### `src/train_model.py`
**What it does:** Trains a Gradient Boosting ML model for each sport.

Key functions:
- `train_football()` — trains model on football data, saves to model/model_football.pkl
- `train_cricket()` — same for cricket
- `train_volleyball()` — same for volleyball
- `train_all()` — trains all three

What happens inside:
```
1. Call preprocess_sport() to get clean data
2. Split data into features (X) and target (y = Performance_Score)
3. Create GradientBoostingRegressor with settings
4. Run 5-fold cross-validation to measure accuracy
5. Print MAE (error) and R² (accuracy) scores
6. Fit model on ALL data (for final deployment)
7. Save model to model/model_sport.pkl using joblib
```

---

### `src/predict.py`
**What it does:** Uses the trained model to predict scores for every player.

Key functions:
- `predict_football()` — loads model, predicts scores, returns ranked DataFrame
- `predict_cricket()` — same for cricket
- `predict_volleyball()` — same for volleyball
- `predict_all()` — all three sports

What happens inside:
```
1. Check if model file exists (if not, train it first)
2. Load the model from model/model_sport.pkl
3. Run preprocess_sport() on the CSV
4. Feed cleaned data into model.predict()
5. Add Predicted_Score and Score_Delta columns
6. Sort players by score (highest first)
7. Add Rank column (1 = best)
8. Return the DataFrame
```

---

### `src/team_selector.py`
**What it does:** Picks the best team from ranked players.

Key functions:
- `select_football_team(df)` — picks 11 players for football
- `select_cricket_team(df)` — picks 11 players for cricket
- `select_volleyball_team(df)` — picks 6 players for volleyball
- `select_all_teams()` — picks for all three

How selection works:
```
1. Define required positions (quotas):
   Football:   1 GK + 4 DEF + 2 MID + 1 WNG + 3 FWD
   Cricket:    3 BAT + 1 WK + 2 AR + 3 BOWL
   Volleyball: 1 SET + 2 OH + 1 OPP + 1 MB + 1 LIB

2. For each required position:
   - Find players with that position
   - Pick the highest ranked ones to fill the quota

3. Fill any remaining slots with best available players

4. Add Selection_Reason column (Quota: Position / Best available)
```

---

### `src/match_data.py`
**What it does:** Provides match history and upcoming fixtures data.

```
FOOTBALL_HISTORY   — 10 past matches with result, score, man of match
FOOTBALL_UPCOMING  — 6 future matches with date, opponent, venue

CRICKET_HISTORY    — 10 past matches (T20I, Test)
CRICKET_UPCOMING   — 6 future fixtures

VOLLEYBALL_HISTORY — 10 past matches
VOLLEYBALL_UPCOMING — 6 future fixtures
```

Functions:
- `get_history(sport)` — returns DataFrame of past matches
- `get_upcoming(sport)` — returns DataFrame of upcoming fixtures
- `get_player_history(sport)` — generates random per-match player stats

---

## model/ — Saved Models (Auto-generated)

These files are created automatically when you run training.
You do NOT need to edit them.

- `model_football.pkl`  — saved Gradient Boosting model for football
- `model_cricket.pkl`   — saved model for cricket
- `model_volleyball.pkl`— saved model for volleyball
- `scaler_football.pkl` — saved MinMax scaler for football features
- `scaler_cricket.pkl`  — saved scaler for cricket
- `scaler_volleyball.pkl`— saved scaler for volleyball

---

## app/ — Dashboard Files

### `app/dashboard.py` ⭐ MOST IMPORTANT
**What it does:** The MAIN FILE that Streamlit runs.

It does these things in order:
```
1. init_session()       — Set safe defaults for all session variables
2. CSS injection        — Apply the dark sports theme
3. Login sidebar        — Show login form if user clicked 🔐 Login
4. Load all data        — Load CSVs, predictions, teams, match data
5. render_navbar()      — Draw the top navigation bar with buttons
6. Page routing         — Based on which button was clicked, show that page
```

---

### `app/styles.py`
**What it does:** Contains ALL the CSS styling for the dashboard.

Defines:
- `CSS` — one big string of CSS that controls fonts, colours, cards, animations
- `SC` — Sport Config dictionary:
  ```python
  SC = {
    "Football":   {"color":"#10b981", "emoji":"⚽", "grad":"linear-gradient(...)"},
    "Cricket":    {"color":"#f59e0b", "emoji":"🏏", "grad":"..."},
    "Volleyball": {"color":"#3b82f6", "emoji":"🏐", "grad":"..."},
  }
  ```
- `DARK` — Plotly chart theme settings (dark background, green grid lines)

---

### `app/data_loader.py`
**What it does:** Loads all data using Streamlit's caching.

The `@st.cache_data` decorator means:
- The function only runs ONCE when the app starts
- Results are stored in memory
- Every time the user clicks a button, the data is already ready (fast!)

Functions:
- `load_raw()` — reads the 3 CSV files
- `load_predictions()` — runs the ML pipeline
- `load_teams()` — runs team selection
- `load_match_history()` — loads past match data
- `load_upcoming()` — loads fixture schedule
- `load_player_history()` — loads per-match player stats
- `allowed_sports(role, sport)` — returns which sports this user can see
- `sport_picker(role, sport)` — shows a sport dropdown (or skips it if only 1 sport)

---

## app/pages/ — Individual Page Files

Each file has one `render(...)` function that draws that page.

| File                   | Page Name        | What it shows                              |
|------------------------|------------------|--------------------------------------------|
| `home.py`              | 🏠 Home          | Welcome, KPIs, top players, how it works  |
| `players.py`           | 📋 Players       | Full player stats table + charts           |
| `player_profiles.py`   | 🧑‍💼 Profiles      | Individual player detail + radar chart     |
| `predictions.py`       | 🤖 Predictions   | ML scores, rankings, predicted vs actual   |
| `teams.py`             | 🏅 Teams         | Selected squad cards, bench, composition   |
| `select_players.py`    | ✏️ Select Players | Hand-pick squad (managers/admin only)      |
| `match_history.py`     | 📅 Matches       | Past results + upcoming fixtures           |
| `leaderboard.py`       | 🏆 Leaderboard   | All-sport combined rankings                |
| `team_report.py`       | 📄 Team Report   | Full squad report + download CSV           |
| `analytics.py`         | 📊 Analytics     | 5 analysis tabs: distribution, age, radar  |

---

## requirements.txt

Lists all Python packages needed to run the project:
```
pandas      — for reading and working with data tables
numpy       — for maths operations
scikit-learn— for the ML model
joblib      — for saving/loading ML models
streamlit   — for the web dashboard
plotly      — for interactive charts
matplotlib  — for chart colour maps
seaborn     — for statistical visualisations
```
