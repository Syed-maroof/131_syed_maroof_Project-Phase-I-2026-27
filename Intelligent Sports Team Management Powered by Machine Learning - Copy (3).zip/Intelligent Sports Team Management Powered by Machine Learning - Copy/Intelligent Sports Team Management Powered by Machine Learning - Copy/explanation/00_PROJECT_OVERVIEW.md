# 00 — Project Overview
## Intelligent Sports Team Management — Powered by Machine Learning

---

## What is this project?

This project is a **web dashboard** that helps select the best Indian sports teams
using **Machine Learning (ML)**.

It covers **three sports**:
- ⚽ **Football** — 18 Indian players
- 🏏 **Cricket**  — 18 Indian players
- 🏐 **Volleyball** — 12 Indian players

The system reads player statistics, trains an ML model for each sport,
predicts how well each player will perform, ranks them, and then
automatically picks the best team.

---

## What problem does it solve?

Selecting a sports team manually is hard — coaches have to compare
dozens of players across many different stats.

This system **automates** that process:
1. Collects all player stats in CSV files
2. Uses ML to score each player (0–100 scale)
3. Ranks players from best to worst
4. Picks the team automatically based on positions needed

---

## Who can use it?

| User        | How they access it          | What they can do                        |
|-------------|-----------------------------|-----------------------------------------|
| **Anyone**  | Open the app, no login      | Browse all pages — view only            |
| **football11** | Login with password      | Select players for Football team        |
| **cricket11**  | Login with password      | Select players for Cricket team         |
| **volley6**    | Login with password      | Select players for Volleyball team      |
| **admin**      | Login with password      | See everything + Admin Panel            |

---

## Project folder structure

```
project/
│
├── app/                    ← Streamlit web dashboard
│   ├── dashboard.py        ← MAIN FILE — starts the app
│   ├── styles.py           ← All CSS styling (colours, fonts, cards)
│   ├── data_loader.py      ← Functions to load data (cached)
│   └── pages/              ← One file per page
│       ├── home.py
│       ├── players.py
│       ├── predictions.py
│       ├── teams.py
│       ├── select_players.py
│       ├── analytics.py
│       ├── match_history.py
│       ├── player_profiles.py
│       ├── leaderboard.py
│       └── team_report.py
│
├── datasets/               ← Raw player data (CSV files)
│   ├── football_players.csv
│   ├── cricket_players.csv
│   └── volleyball_players.csv
│
├── src/                    ← Machine Learning code
│   ├── preprocess.py       ← Cleans and prepares data
│   ├── train_model.py      ← Trains the ML models
│   ├── predict.py          ← Uses models to score players
│   ├── team_selector.py    ← Picks the best team
│   └── match_data.py       ← Match history & fixture data
│
├── model/                  ← Saved ML models (auto-generated)
│   ├── model_football.pkl
│   ├── model_cricket.pkl
│   └── model_volleyball.pkl
│
├── explanation/            ← YOU ARE HERE — plain English docs
│
└── requirements.txt        ← Python packages needed
```

---

## Technologies used

| Technology     | What it does in this project                     |
|----------------|--------------------------------------------------|
| Python         | The programming language everything is written in |
| Streamlit      | Turns Python code into a web dashboard           |
| pandas         | Reads and manipulates CSV data tables            |
| scikit-learn   | The ML library — trains the Gradient Boosting model |
| plotly         | Creates interactive charts and graphs            |
| joblib         | Saves and loads trained ML models to disk        |

---

## Read the other files in this folder to learn more:

- `01_HOW_ML_WORKS.md`   — How the machine learning actually works
- `02_FILE_BY_FILE.md`   — What every single file does
- `03_HOW_TO_RUN.md`     — How to start the app step by step
- `04_PAGES_GUIDE.md`    — What each page in the dashboard shows
- `05_LOGIN_GUIDE.md`    — All login details and what each account can do
