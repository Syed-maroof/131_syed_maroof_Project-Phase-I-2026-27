# 01 — How Machine Learning Works in This Project

---

## Simple explanation first

Imagine you are a cricket coach. You look at a player's runs, wickets,
fitness, and form — then you decide if they are good or not.

Machine Learning does the same thing — but with **maths and data**
instead of gut feeling. It learns patterns from the data and gives
each player a **score between 0 and 100**.

---

## The 5 steps — explained simply

---

### Step 1 — Data Collection

We have 3 CSV files, one per sport. Each file has rows (players)
and columns (stats).

**Football example:**
```
Player_Name      | Goals | Assists | Fitness | Recent_Form | Injury | Score
Sunil Chhetri    |  8    |   3     |  88     |    91       |   1    |  89
Jeakson Singh    |  2    |   4     |  94     |    90       |   0    |  92
```

Every column is a **feature** (input to the model).
The last column `Performance_Score` is what we want to **predict**.

---

### Step 2 — Preprocessing (Cleaning the data)

Raw data is messy. We clean it in 3 ways:

**a) Remove missing values**
If a player row has empty/missing data, we remove that row.

**b) Remove outliers using IQR**
Outlier = a value that is extremely different from others.
Example: if most players score 5–20 goals, but one has 500 — that's an outlier.
We clip outliers to a safe range using a formula called IQR (Interquartile Range).

**c) Feature Engineering**
We create NEW columns from existing ones to help the model:
- Football: `Goals_per_Match = Goals / Matches`
- Cricket:  `Wickets_per_Match = Wickets / Matches`
- Both: `Availability_Score = Fitness - (Injury_Count × 3)`

**d) MinMax Scaling**
All numbers are converted to a scale of 0 to 1.
This prevents big numbers (like Runs = 800) from dominating small ones (like Wickets = 20).

---

### Step 3 — Training the ML Model

We use **Gradient Boosting Regressor** — a powerful ML algorithm.

**How Gradient Boosting works (simple version):**

1. Start with a rough guess (e.g. average score for all players)
2. Look at where the guess was wrong
3. Build a small **decision tree** to correct those mistakes
4. Repeat 200 times — each tree fixes errors from the previous one
5. Final prediction = all 200 trees combined

It's like asking 200 experts, each one fixing the mistakes of the previous one.

**Settings we use:**
```
n_estimators = 200      # 200 trees
learning_rate = 0.05    # Each tree contributes a small amount (5%)
max_depth = 3           # Each tree is kept simple (3 levels deep)
```

**Cross-validation (5-fold):**
We split the data into 5 parts. We train on 4 parts and test on 1 part.
We do this 5 times (rotating which part is the test).
This gives us an honest measure of how good the model is.

**Metrics we measure:**
- **MAE** (Mean Absolute Error) — average error in predicted score (lower = better)
- **R²** (R-squared) — how well predictions match actual scores (closer to 1 = better)

---

### Step 4 — Prediction & Ranking

Once trained, the model predicts a `Predicted_Score` for every player.

Example output:
```
Rank | Player_Name      | Predicted_Score | Actual_Score | Delta
  1  | Virat Kohli      |    94.00        |    94        | +0.00
  2  | Jasprit Bumrah   |    94.00        |    94        | +0.00
  3  | Yashasvi Jaiswal |    93.01        |    93        | +0.01
```

Players are sorted from highest to lowest predicted score.

---

### Step 5 — Team Selection

We use a **quota-based greedy selector**:

1. **Fill mandatory positions first** — e.g. must have 1 Goalkeeper
2. **Fill remaining slots** with whoever has the highest score left

**Football (11 players):**
```
1 Goalkeeper + 4 Defenders + 3 Midfielders + 1 Winger + 3 Forwards
→ If any slot left over, pick best available player
```

**Cricket (11 players):**
```
3 Batsmen + 1 Wicketkeeper + 2 All-Rounders + 3 Bowlers + 2 best remaining
```

**Volleyball (6 players):**
```
1 Setter + 2 Outside Hitters + 1 Opposite + 1 Middle Blocker + 1 Libero
```

---

## Why Gradient Boosting?

We chose Gradient Boosting because:
- It works well on **small datasets** (we only have 12–18 players per sport)
- It handles **mixed features** (some columns are numbers, some are categories)
- It shows **feature importance** — tells us which stats matter most
- It is more accurate than simpler models like Linear Regression

---

## Feature Importance — What matters most?

After training, the model tells us which features affected the score the most.

For all three sports, the top features tend to be:
1. `Recent_Form` — How well the player performed in their last few games
2. `Fitness_Score` — Physical condition
3. `Availability_Score` — Fitness minus injury penalty

This makes sense! A player who is fit, in good form and not injured
will almost always perform better.

---

## Summary table

| Step          | File          | What happens                            |
|---------------|---------------|-----------------------------------------|
| Preprocessing | preprocess.py | Clean data, scale to 0–1               |
| Training      | train_model.py| Train Gradient Boosting, save .pkl file |
| Prediction    | predict.py    | Load model, predict score for each player|
| Team select   | team_selector.py | Pick best team using quota rules    |
| Dashboard     | app/          | Show everything in a web interface     |
