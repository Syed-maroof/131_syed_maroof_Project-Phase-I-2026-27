# 03 — How to Run This Project

Step-by-step guide to start the dashboard on your computer.

---

## Requirements

- Windows PC (the instructions below are for Windows)
- Python already installed
- The project folder on your Desktop

---

## Step 1 — Open a Terminal

Press `Windows Key + R`, type `cmd`, press Enter.
OR open **PowerShell** by right-clicking the Start menu.

---

## Step 2 — Navigate to the project folder

Type this command and press Enter:
```
cd "C:\Users\maroo\OneDrive\Desktop\Intelligent Sports Team Management Powered by Machine Learning"
```

---

## Step 3 — Activate the virtual environment

The project has its own Python environment called `venv`.
Activate it:
```
.\venv\Scripts\activate
```

You should see `(venv)` appear at the start of the line.

---

## Step 4 — Install required packages (first time only)

You only need to do this once:
```
pip install -r requirements.txt
```

Wait for all packages to download and install.

---

## Step 5 — Start the dashboard

```
python -m streamlit run app/dashboard.py
```

---

## Step 6 — Open in browser

Streamlit will print something like:
```
Local URL: http://localhost:8501
```

Open your browser (Chrome, Edge, Firefox) and go to:
```
http://localhost:8501
```

The dashboard will load. ✅

---

## Step 7 — Use the dashboard

- You can browse all pages **without logging in**
- To access **Select Players** or **Admin Panel**, click 🔐 Login in the top bar
- See `05_LOGIN_GUIDE.md` for all login details

---

## Stopping the server

Go back to the terminal and press `Ctrl + C` to stop Streamlit.

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'streamlit'"
→ Run: `pip install -r requirements.txt`

### "ModuleNotFoundError: No module named 'plotly'"
→ Run: `.\venv\Scripts\pip3.exe install plotly`

### "Model not found — training now..."
→ This is normal on first run. The ML models will train automatically.
   It takes about 10–20 seconds. Wait for it to finish.

### Page loads but shows errors
→ Make sure you are in the correct folder before running the command.

### Port already in use
→ Run on a different port:
```
python -m streamlit run app/dashboard.py --server.port 8502
```
Then open `http://localhost:8502` in your browser.

---

## Quick reference — all commands

```powershell
# Go to project folder
cd "C:\Users\maroo\OneDrive\Desktop\Intelligent Sports Team Management Powered by Machine Learning"

# Activate virtual environment
.\venv\Scripts\activate

# Install packages (first time only)
pip install -r requirements.txt

# Start the dashboard
python -m streamlit run app/dashboard.py

# Open in browser
# Go to: http://localhost:8501
```
