/* ==========================================================================
   AthletiX IPL AI — Main Application & Engine Script
   File: js/app.js
   Description: Handles page navigation highlighting, animated counters, FAQ accordions,
                IPL match outcome simulation, player radar rendering, and toast alerts.
   ========================================================================== */

// Execute initialization functions once the HTML Document Object Model (DOM) is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();       // Initialize sticky header, mobile drawer & active URL highlighting
  initCounters();         // Initialize scroll-triggered animated statistic counters
  initFAQAccordion();     // Initialize expand/collapse FAQ accordions
  initPortfolioFilter();  // Initialize project category filter buttons
  initPlatformDemo();     // Initialize IPL Match Simulator, Player Radar, and Leaderboard
  initModalAndToasts();   // Initialize contact forms and toast notification alerts
});

/* ── 1. Navigation, Sticky Header & Active Page Highlighter ──────────── */
function initNavigation() {
  // Select the main sticky header element
  const header = document.querySelector('.header-nav');
  // Select the mobile hamburger menu button
  const hamburger = document.querySelector('.hamburger-btn');
  // Select the full-screen mobile menu drawer overlay
  const mobileMenu = document.querySelector('.mobile-menu-overlay');

  // Listen for window scroll events to toggle glassmorphism shadow on header
  window.addEventListener('scroll', () => {
    // If user has scrolled down more than 40 pixels, add 'scrolled' CSS class
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      // Otherwise, remove 'scrolled' class when at the top of the page
      header.classList.remove('scrolled');
    }
  });

  // Attach click event to hamburger button to toggle mobile menu overlay
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
    });

    // Close mobile drawer when user clicks any navigation link inside it
    mobileMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.remove('open');
      });
    });
  }

  // Get the current page filename from window location URL (defaulting to index.html if empty)
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  
  // Highlight active navigation link matching current URL path
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      link.classList.add('active'); // Add active CSS class for glowing underline
    } else {
      link.classList.remove('active');
    }
  });
}

/* ── 2. Animated Number Counters ─────────────────────────────────────── */
function initCounters() {
  // Select all DOM elements that have a data-counter attribute
  const counters = document.querySelectorAll('[data-counter]');
  if (!counters.length) return;

  // Create IntersectionObserver to detect when counter elements scroll into view
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = entry.target;
        // Parse target end value, prefix, suffix, and decimal precision
        const finalValue = parseFloat(target.getAttribute('data-counter'));
        const prefix = target.getAttribute('data-prefix') || '';
        const suffix = target.getAttribute('data-suffix') || '';
        const decimals = parseInt(target.getAttribute('data-decimals')) || 0;

        let startValue = 0;
        const duration = 2000; // Animation duration in milliseconds (2 seconds)
        const startTime = performance.now();

        // Animation frame loop for smooth easing count-up
        function updateCounter(currentTime) {
          const elapsed = currentTime - startTime;
          const progress = Math.min(elapsed / duration, 1);
          // Ease-out exponential formula for smooth slowdown at the end
          const easeProgress = 1 - Math.pow(2, -10 * progress);
          const currentValue = startValue + (finalValue - startValue) * easeProgress;

          // Format and render current animated value to screen text
          target.textContent = `${prefix}${currentValue.toFixed(decimals)}${suffix}`;

          if (progress < 1) {
            requestAnimationFrame(updateCounter); // Continue animation loop
          } else {
            target.textContent = `${prefix}${finalValue.toFixed(decimals)}${suffix}`; // Final exact value
          }
        }

        requestAnimationFrame(updateCounter);
        observer.unobserve(target); // Unobserve element after animation triggers once
      }
    });
  }, { threshold: 0.3 }); // Trigger when 30% of element is visible

  counters.forEach(c => observer.observe(c));
}

/* ── 3. FAQ Accordion ─────────────────────────────────────────────────── */
function initFAQAccordion() {
  // Select all FAQ container elements
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    // Attach click listener to question header
    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      // Collapse all other active FAQ items
      faqItems.forEach(i => i.classList.remove('active'));
      // Toggle clicked item
      if (!isActive) {
        item.classList.add('active');
      }
    });
  });
}

/* ── 4. Portfolio Filter ─────────────────────────────────────────────── */
function initPortfolioFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Remove active class from all filter buttons
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');
      projectCards.forEach(card => {
        const category = card.getAttribute('data-category');
        // If filter is 'all' or matches card category, display card
        if (filter === 'all' || category === filter) {
          card.style.display = 'flex';
          card.style.animation = 'fadeInView 0.4s ease forwards';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

/* ── 5. Interactive IPL Platform Dashboard Engine ─────────────────────── */
function initPlatformDemo() {
  // Select sidebar tab buttons and subpanel containers
  const demoTabs = document.querySelectorAll('.demo-tab-btn');
  const subpanels = document.querySelectorAll('.demo-subpanel');

  if (demoTabs.length) {
    demoTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        demoTabs.forEach(t => t.classList.remove('active'));
        subpanels.forEach(p => p.classList.remove('active'));

        tab.classList.add('active');
        const panelId = tab.getAttribute('data-tab-panel');
        const targetPanel = document.getElementById(panelId);
        if (targetPanel) {
          targetPanel.classList.add('active');
        }
      });
    });
  }

  // Populate Dropdowns for Team A, Team B, and Venues with official dataset
  const teamASelect = document.getElementById('select-team-a');
  const teamBSelect = document.getElementById('select-team-b');
  const venueSelect = document.getElementById('select-venue');

  if (teamASelect && teamBSelect) {
    // Populate select options with all 10 IPL franchises
    teamASelect.innerHTML = ATHLETIX_DATA.teams.map(t => `<option value="${t.code}" ${t.code==='CSK'?'selected':''}>${t.name} (${t.code})</option>`).join('');
    teamBSelect.innerHTML = ATHLETIX_DATA.teams.map(t => `<option value="${t.code}" ${t.code==='MI'?'selected':''}>${t.name} (${t.code})</option>`).join('');
  }

  if (venueSelect) {
    // Populate select options with iconic IPL stadium venues
    venueSelect.innerHTML = ATHLETIX_DATA.venues.map(v => `<option value="${v.id}">${v.name} — ${v.pitch}</option>`).join('');
  }

  // Match Predictor Simulation Execution
  const simulateBtn = document.getElementById('btn-run-simulation');
  if (simulateBtn) {
    simulateBtn.addEventListener('click', () => {
      const teamA = teamASelect ? teamASelect.value : 'CSK';
      const teamB = teamBSelect ? teamBSelect.value : 'MI';
      const venueId = venueSelect ? venueSelect.value : 'wankhede';

      // Ensure Team A and Team B are not identical
      if (teamA === teamB) {
        showToast('⚠️ Please select two different IPL teams for comparison!', 'warning');
        return;
      }

      // Update button state while simulating
      simulateBtn.innerHTML = '⚡ Computing ML Inferences...';
      simulateBtn.disabled = true;

      // Simulate ML algorithm computation delay (1 second)
      setTimeout(() => {
        const teamAObj = ATHLETIX_DATA.teams.find(t => t.code === teamA) || ATHLETIX_DATA.teams[0];
        const teamBObj = ATHLETIX_DATA.teams.find(t => t.code === teamB) || ATHLETIX_DATA.teams[1];
        const venueObj = ATHLETIX_DATA.venues.find(v => v.id === venueId) || ATHLETIX_DATA.venues[0];

        // Calculate win probability based on team historical win rates & home venue advantage
        const baseA = teamAObj.winRate;
        const baseB = teamBObj.winRate;
        const total = baseA + baseB;
        let probA = Math.round((baseA / total) * 100);

        // Apply venue bias adjustment
        if (teamAObj.primaryVenue.toLowerCase().includes(venueObj.name.split(',')[0].toLowerCase())) probA += 8;
        if (teamBObj.primaryVenue.toLowerCase().includes(venueObj.name.split(',')[0].toLowerCase())) probA -= 8;
        probA = Math.max(15, Math.min(85, probA)); // Clamp between 15% and 85%
        let probB = 100 - probA;

        // Render calculated prediction to UI elements
        document.getElementById('sim-team-a-name').textContent = teamAObj.name;
        document.getElementById('sim-team-b-name').textContent = teamBObj.name;
        document.getElementById('sim-prob-a').textContent = `${probA}%`;
        document.getElementById('sim-prob-b').textContent = `${probB}%`;
        document.getElementById('sim-bar-a').style.width = `${probA}%`;
        document.getElementById('sim-bar-b').style.width = `${probB}%`;

        // Make result panel visible
        document.getElementById('sim-result-box').style.display = 'block';
        simulateBtn.innerHTML = '⚡ Re-Run AI Match Simulation';
        simulateBtn.disabled = false;

        showToast(`🏏 IPL Simulation Complete! ${probA > probB ? teamAObj.name : teamBObj.name} has higher win odds at ${venueObj.name}.`, 'success');
      }, 1000);
    });
  }

  // Player Radar Profile Selector Listener
  const playerSelect = document.getElementById('profile-player-select');
  if (playerSelect) {
    playerSelect.innerHTML = ATHLETIX_DATA.players.map(p => `
      <option value="${p.id}">${p.name} (${p.team} - ${p.role})</option>
    `).join('');

    playerSelect.addEventListener('change', (e) => {
      const id = parseInt(e.target.value);
      const player = ATHLETIX_DATA.players.find(p => p.id === id);
      if (player) {
        document.getElementById('radar-player-name').textContent = player.name;
        document.getElementById('radar-player-role').textContent = `${player.team} • ${player.role}`;
        document.getElementById('radar-bat-avg').textContent = player.battingAvg;
        document.getElementById('radar-strike-rate').textContent = player.strikeRate;
        document.getElementById('radar-synergy-index').textContent = player.synergy;
        document.getElementById('radar-valuation').textContent = `₹${player.price} Crore`;
      }
    });
  }

  // Franchise Leaderboard Renderer
  const leaderboardTable = document.getElementById('leaderboard-tbody');
  if (leaderboardTable) {
    const sortedTeams = [...ATHLETIX_DATA.teams].sort((a, b) => b.winRate - a.winRate);
    leaderboardTable.innerHTML = sortedTeams.map((t, idx) => `
      <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
        <td style="padding:1rem; font-weight:800; color:var(--text-muted);">${idx + 1}</td>
        <td style="padding:1rem; font-weight:700; color:#fff; display:flex; align-items:center; gap:0.75rem;">
          <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:${t.color};"></span>
          <span>${t.name}</span>
        </td>
        <td style="padding:1rem; font-weight:600; color:var(--text-muted);">${t.titles} ${t.titles===1?'Title':'Titles'}</td>
        <td style="padding:1rem; font-weight:700; color:var(--accent-emerald-light);">${t.winRate}%</td>
        <td style="padding:1rem; font-weight:600; color:var(--accent-cyan-light);">${t.winRate > 55 ? 'High (85% Playoff)' : 'Moderate (45% Playoff)'}</td>
      </tr>
    `).join('');
  }
}

/* ── 6. Toast Alerts ─────────────────────────────────────────────────── */
function initModalAndToasts() {
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('🚀 Thank you! Your inquiry has been sent to our IPL Data Science Team.', 'success');
      contactForm.reset();
    });
  }

  const ctaForm = document.getElementById('hero-cta-form');
  if (ctaForm) {
    ctaForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('🎉 Request received! Check your email for IPL AI platform access.', 'success');
      ctaForm.reset();
    });
  }
}

// Function to generate floating glass toast alert popups
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>${message}</span>`;

  container.appendChild(toast);

  // Auto-remove toast after 4 seconds
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}
