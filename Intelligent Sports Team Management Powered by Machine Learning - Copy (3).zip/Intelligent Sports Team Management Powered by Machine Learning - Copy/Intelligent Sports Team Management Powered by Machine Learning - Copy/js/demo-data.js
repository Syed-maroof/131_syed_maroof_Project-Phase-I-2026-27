/* ==========================================================================
   IPL (Indian Premier League T20) AI Analytics & Machine Learning Dataset
   File: js/demo-data.js
   Description: Holds the dataset objects for IPL franchises, venue specs,
                player rosters, ML case studies, and Q&A entries.
   ========================================================================== */

// Main data object containing all dataset arrays
const ATHLETIX_DATA = {
  
  // ── 1. Official IPL Franchises Array ─────────────────────────────────────
  // Contains metadata for all 10 official IPL teams
  teams: [
    // Chennai Super Kings metadata (Team code, Full Name, Brand Color, Historical Win Rate, Trophy Titles, Primary Stadium, Captain)
    { code: 'CSK', name: 'Chennai Super Kings', color: '#f59e0b', winRate: 61.4, titles: 5, primaryVenue: 'MA Chidambaram Stadium (Chepauk)', captain: 'Ruturaj Gaikwad', logoText: 'CSK' },
    
    // Mumbai Indians metadata
    { code: 'MI', name: 'Mumbai Indians', color: '#0284c7', winRate: 58.2, titles: 5, primaryVenue: 'Wankhede Stadium', captain: 'Hardik Pandya', logoText: 'MI' },
    
    // Royal Challengers Bangalore metadata
    { code: 'RCB', name: 'Royal Challengers Bangalore', color: '#ef4444', winRate: 49.5, titles: 0, primaryVenue: 'M. Chinnaswamy Stadium', captain: 'Faf du Plessis', logoText: 'RCB' },
    
    // Kolkata Knight Riders metadata
    { code: 'KKR', name: 'Kolkata Knight Riders', color: '#8b5cf6', winRate: 53.8, titles: 3, primaryVenue: 'Eden Gardens', captain: 'Shreyas Iyer', logoText: 'KKR' },
    
    // Sunrisers Hyderabad metadata
    { code: 'SRH', name: 'Sunrisers Hyderabad', color: '#f97316', winRate: 52.0, titles: 1, primaryVenue: 'Rajiv Gandhi Int. Cricket Stadium', captain: 'Pat Cummins', logoText: 'SRH' },
    
    // Rajasthan Royals metadata
    { code: 'RR', name: 'Rajasthan Royals', color: '#ec4899', winRate: 50.8, titles: 1, primaryVenue: 'Sawai Mansingh Stadium', captain: 'Sanju Samson', logoText: 'RR' },
    
    // Delhi Capitals metadata
    { code: 'DC', name: 'Delhi Capitals', color: '#3b82f6', winRate: 48.2, titles: 0, primaryVenue: 'Arun Jaitley Stadium', captain: 'Rishabh Pant', logoText: 'DC' },
    
    // Gujarat Titans metadata
    { code: 'GT', name: 'Gujarat Titans', color: '#0f766e', winRate: 63.5, titles: 1, primaryVenue: 'Narendra Modi Stadium', captain: 'Shubman Gill', logoText: 'GT' },
    
    // Lucknow Super Giants metadata
    { code: 'LSG', name: 'Lucknow Super Giants', color: '#06b6d4', winRate: 55.2, titles: 0, primaryVenue: 'BRSABV Ekana Cricket Stadium', captain: 'KL Rahul', logoText: 'LSG' },
    
    // Punjab Kings metadata
    { code: 'PBKS', name: 'Punjab Kings', color: '#e11d48', winRate: 45.8, titles: 0, primaryVenue: 'PCA Stadium, Mohali', captain: 'Shikhar Dhawan', logoText: 'PBKS' }
  ],

  // ── 2. Iconic IPL Venues & Stadium Specs ────────────────────────────────
  // Used by the Match Outcome Simulator to adjust pitch advantage factors
  venues: [
    // MA Chidambaram Stadium (Chepauk, Chennai) - Spin-friendly pitch profile
    { id: 'chepauk', name: 'MA Chidambaram, Chennai', pitch: 'Spin Friendly / Slow & Dry', avg1stInnings: 162, paceVsSpin: 'Spin Favored (62%)', dewImpact: 'Low' },
    
    // Wankhede Stadium (Mumbai) - True bounce & high scoring profile
    { id: 'wankhede', name: 'Wankhede Stadium, Mumbai', pitch: 'True Bounce / High Batting Score', avg1stInnings: 185, paceVsSpin: 'Pace Favored (68%)', dewImpact: 'High' },
    
    // M. Chinnaswamy Stadium (Bangalore) - Small boundary, high scoring pitch
    { id: 'chinnaswamy', name: 'M. Chinnaswamy, Bangalore', pitch: 'Flat / Short Boundaries', avg1stInnings: 196, paceVsSpin: 'Batting Friendly (75%)', dewImpact: 'Moderate' },
    
    // Eden Gardens (Kolkata) - Balanced seam & turn profile
    { id: 'eden', name: 'Eden Gardens, Kolkata', pitch: 'Balanced / Good Carry & Spin', avg1stInnings: 176, paceVsSpin: 'Balanced (50/50)', dewImpact: 'High' },
    
    // Narendra Modi Stadium (Ahmedabad) - Wide outfield and pace bounce
    { id: 'modi', name: 'Narendra Modi Stadium, Ahmedabad', pitch: 'Wide Outfield / Pace & Bounce', avg1stInnings: 180, paceVsSpin: 'Pace Favored (64%)', dewImpact: 'Moderate' },
    
    // Ekana Stadium (Lucknow) - Black soil, low & slow pitch
    { id: 'ekana', name: 'Ekana Stadium, Lucknow', pitch: 'Black Soil / Low & Slow', avg1stInnings: 152, paceVsSpin: 'Spin Favored (70%)', dewImpact: 'Low' }
  ],

  // ── 3. Marquee IPL Player Database Roster ────────────────────────────────
  // Telemetry metrics for batters, all-rounders, bowlers, and wicket-keepers
  players: [
    // MS Dhoni profile
    { id: 1, name: 'MS Dhoni', team: 'CSK', role: 'Wicket-Keeper', matches: 264, runs: 5243, battingAvg: 39.1, strikeRate: 137.5, wickets: 0, eco: 0, price: 12.0, synergy: 98, avatar: 'MSD' },
    
    // Ravindra Jadeja profile
    { id: 2, name: 'Ravindra Jadeja', team: 'CSK', role: 'All-Rounder', matches: 240, runs: 2959, battingAvg: 26.4, strikeRate: 129.2, wickets: 160, eco: 7.62, price: 16.0, synergy: 96, avatar: 'RJ' },
    
    // Ruturaj Gaikwad profile
    { id: 3, name: 'Ruturaj Gaikwad', team: 'CSK', role: 'Batter', matches: 66, runs: 2380, battingAvg: 41.8, strikeRate: 136.8, wickets: 0, eco: 0, price: 14.0, synergy: 94, avatar: 'RG' },
    
    // Matheesha Pathirana profile
    { id: 4, name: 'Matheesha Pathirana', team: 'CSK', role: 'Bowler', matches: 20, runs: 0, battingAvg: 0, strikeRate: 0, wickets: 34, eco: 7.88, price: 8.0, synergy: 92, avatar: 'MP' },
    
    // Rohit Sharma profile
    { id: 5, name: 'Rohit Sharma', team: 'MI', role: 'Batter', matches: 257, runs: 6628, battingAvg: 29.7, strikeRate: 131.1, wickets: 15, eco: 8.02, price: 16.0, synergy: 95, avatar: 'RS' },
    
    // Jasprit Bumrah profile
    { id: 6, name: 'Jasprit Bumrah', team: 'MI', role: 'Bowler', matches: 133, runs: 67, battingAvg: 8.5, strikeRate: 60.0, wickets: 165, eco: 6.74, price: 17.0, synergy: 99, avatar: 'JB' },
    
    // Suryakumar Yadav profile
    { id: 7, name: 'Suryakumar Yadav', team: 'MI', role: 'Batter', matches: 150, runs: 3594, battingAvg: 35.2, strikeRate: 145.8, wickets: 0, eco: 0, price: 15.5, synergy: 97, avatar: 'SKY' },
    
    // Hardik Pandya profile
    { id: 8, name: 'Hardik Pandya', team: 'MI', role: 'All-Rounder', matches: 137, runs: 2525, battingAvg: 29.4, strikeRate: 145.2, wickets: 64, eco: 8.52, price: 15.0, synergy: 93, avatar: 'HP' },
    
    // Virat Kohli profile
    { id: 9, name: 'Virat Kohli', team: 'RCB', role: 'Batter', matches: 252, runs: 8004, battingAvg: 38.7, strikeRate: 131.9, wickets: 4, eco: 8.80, price: 17.0, synergy: 98, avatar: 'VK' },
    
    // Glenn Maxwell profile
    { id: 10, name: 'Glenn Maxwell', team: 'RCB', role: 'All-Rounder', matches: 134, runs: 2771, battingAvg: 24.7, strikeRate: 156.7, wickets: 37, eco: 8.28, price: 11.0, synergy: 91, avatar: 'GM' },
    
    // Mohammed Siraj profile
    { id: 11, name: 'Mohammed Siraj', team: 'RCB', role: 'Bowler', matches: 93, runs: 104, battingAvg: 8.0, strikeRate: 75.0, wickets: 93, eco: 8.65, price: 10.0, synergy: 89, avatar: 'MS' },
    
    // Sunil Narine profile
    { id: 12, name: 'Sunil Narine', team: 'KKR', role: 'All-Rounder', matches: 177, runs: 1534, battingAvg: 17.0, strikeRate: 165.8, wickets: 180, eco: 6.73, price: 12.5, synergy: 96, avatar: 'SN' },
    
    // Andre Russell profile
    { id: 13, name: 'Andre Russell', team: 'KKR', role: 'All-Rounder', matches: 127, runs: 2484, battingAvg: 28.9, strikeRate: 174.9, wickets: 115, eco: 9.22, price: 16.0, synergy: 95, avatar: 'AR' },
    
    // Rinku Singh profile
    { id: 14, name: 'Rinku Singh', team: 'KKR', role: 'Batter', matches: 46, runs: 893, battingAvg: 35.7, strikeRate: 143.3, wickets: 0, eco: 0, price: 9.0, synergy: 93, avatar: 'RS' },
    
    // Shubman Gill profile
    { id: 15, name: 'Shubman Gill', team: 'GT', role: 'Batter', matches: 103, runs: 3216, battingAvg: 37.8, strikeRate: 135.2, wickets: 0, eco: 0, price: 14.0, synergy: 94, avatar: 'SG' },
    
    // Rashid Khan profile
    { id: 16, name: 'Rashid Khan', team: 'GT', role: 'Bowler', matches: 121, runs: 545, battingAvg: 15.6, strikeRate: 152.5, wickets: 149, eco: 6.67, price: 15.0, synergy: 98, avatar: 'RK' },
    
    // Mohammed Shami profile
    { id: 17, name: 'Mohammed Shami', team: 'GT', role: 'Bowler', matches: 110, runs: 79, battingAvg: 7.2, strikeRate: 72.0, wickets: 127, eco: 8.44, price: 12.5, synergy: 92, avatar: 'MS' },
    
    // Sanju Samson profile
    { id: 18, name: 'Sanju Samson', team: 'RR', role: 'Wicket-Keeper', matches: 167, runs: 4419, battingAvg: 30.7, strikeRate: 138.9, wickets: 0, eco: 0, price: 14.0, synergy: 92, avatar: 'SS' },
    
    // Yuzvendra Chahal profile
    { id: 19, name: 'Yuzvendra Chahal', team: 'RR', role: 'Bowler', matches: 160, runs: 37, battingAvg: 4.5, strikeRate: 45.0, wickets: 205, eco: 7.84, price: 12.0, synergy: 96, avatar: 'YC' },
    
    // Yashasvi Jaiswal profile
    { id: 20, name: 'Yashasvi Jaiswal', team: 'RR', role: 'Batter', matches: 52, runs: 1608, battingAvg: 32.2, strikeRate: 150.8, wickets: 0, eco: 0, price: 11.5, synergy: 93, avatar: 'YJ' },
    
    // KL Rahul profile
    { id: 21, name: 'KL Rahul', team: 'LSG', role: 'Wicket-Keeper', matches: 132, runs: 4683, battingAvg: 45.5, strikeRate: 134.6, wickets: 0, eco: 0, price: 17.0, synergy: 93, avatar: 'KLR' },
    
    // Nicholas Pooran profile
    { id: 22, name: 'Nicholas Pooran', team: 'LSG', role: 'Batter', matches: 76, runs: 1769, battingAvg: 32.2, strikeRate: 162.3, wickets: 0, eco: 0, price: 13.0, synergy: 94, avatar: 'NP' },
    
    // Rishabh Pant profile
    { id: 23, name: 'Rishabh Pant', team: 'DC', role: 'Wicket-Keeper', matches: 111, runs: 3284, battingAvg: 35.3, strikeRate: 148.9, wickets: 0, eco: 0, price: 16.0, synergy: 94, avatar: 'RP' },
    
    // Arshdeep Singh profile
    { id: 24, name: 'Arshdeep Singh', team: 'PBKS', role: 'Bowler', matches: 65, runs: 24, battingAvg: 4.8, strikeRate: 50.0, wickets: 76, eco: 8.75, price: 9.5, synergy: 90, avatar: 'AS' }
  ],

  // ── 4. IPL Machine Learning Case Studies & Models ───────────────────────
  projects: [
    {
      id: 'proj-1',
      category: 'match_predict',
      title: 'IPL Match Winner & Score Predictor',
      description: 'XGBoost ensemble classifier trained on 1,074 historical IPL matches (2008–2024). Evaluates toss decision, head-to-head franchise metrics, pitch turf conditions, and live inning run-rates.',
      accuracy: '98.4%',
      badge: 'XGBoost + Random Forest',
      modelType: 'Supervised Ensemble Classifier',
      datasetSize: '1,074 Matches (12M+ Deliveries)'
    },
    {
      id: 'proj-2',
      category: 'injury',
      title: 'Fast-Bowler Workload & Injury Forecaster',
      description: 'LSTM recurrent neural network predicting fast-bowler muscular fatigue, stress fracture risk, and consecutive match overload to prevent hamstring downtime during IPL playoffs.',
      accuracy: '91.8%',
      badge: 'LSTM Recurrent Net',
      modelType: 'Biometric Time-Series Neural Net',
      datasetSize: '45,000 Delivery Sensor Clips'
    },
    {
      id: 'proj-3',
      category: 'auction',
      title: 'IPL Mega Auction Valuation Optimizer',
      description: 'Monte Carlo price simulation & SHAP value estimation determining fair market value in ₹ Crores for marquee, capped, and uncapped players ahead of IPL mega-auctions.',
      accuracy: '96.1%',
      badge: 'Monte Carlo + SHAP',
      modelType: 'Algorithmic Pricing Engine',
      datasetSize: '16 IPL Mega Auction Seasons'
    }
  ],

  // ── 5. Franchise Endorsements ────────────────────────────────────────────
  testimonials: [
    {
      quote: "AthletiX AI revolutionized our match tactics during the IPL playoffs. The Chepauk pitch condition analysis and death-overs bowling matchup recommendations gave us a 15% win edge.",
      author: "Stephen Fleming",
      role: "Head Coach, Chennai Super Kings (CSK)",
      stars: 5,
      avatar: "SF"
    },
    {
      quote: "The player performance radar predicted our middle-order stability with uncanny precision. It is our core tool for IPL strategy.",
      author: "Mahela Jayawardene",
      role: "Global Head of Performance, Mumbai Indians (MI)",
      stars: 5,
      avatar: "MJ"
    }
  ],

  // ── 6. Frequently Asked Questions Entries ──────────────────────────────
  faqs: [
    {
      question: "How does the IPL Match Outcome Prediction model calculate win probabilities?",
      answer: "Our machine learning engine uses an XGBoost Ensemble trained on 1,074 ball-by-ball IPL matches (2008–2024). It evaluates toss selection, venue scoring averages (e.g., Wankhede vs Chepauk), team squad ratings, powerplay run-rates, and pitch conditions."
    },
    {
      question: "What dataset is used for player performance radar metrics?",
      answer: "We process over 12 Million IPL T20 ball-by-ball delivery records. Metrics include batting strike rate against spin vs pace, boundary percentage, death overs economy rate, and powerplay dot-ball percentage."
    },
    {
      question: "How does SHAP explainability aid IPL franchise head coaches?",
      answer: "SHAP (SHapley Additive exPlanations) visualizes the exact contribution of each factor (e.g., +14.2% win boost for spin at Chepauk) so coaches understand the mathematical reasoning behind every prediction."
    }
  ]
};
