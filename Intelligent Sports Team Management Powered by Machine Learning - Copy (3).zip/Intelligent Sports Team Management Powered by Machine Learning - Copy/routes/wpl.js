const express   = require('express');
const WplPlayer = require('../models/WplPlayer');
const router    = express.Router();

// GET all WPL players  ?search=&team=&role=&sort=-performance_score&limit=200
router.get('/', async (req, res) => {
  try {
    const { search, team, role, nationality, sort = '-performance_score', limit = 200 } = req.query;
    const q = {};
    if (search)      q.name        = { $regex: search, $options: 'i' };
    if (team)        q.team        = { $regex: team,   $options: 'i' };
    if (role)        q.role        = role;
    if (nationality) q.nationality = nationality;
    const players = await WplPlayer.find(q).sort(sort).limit(Number(limit));
    res.json({ success: true, count: players.length, data: players });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// GET /meta/teams
router.get('/meta/teams', async (req, res) => {
  try {
    const teams = await WplPlayer.distinct('team');
    res.json({ success: true, data: teams.filter(Boolean).sort() });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// GET /meta/leaderboard
router.get('/meta/leaderboard', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const players = await WplPlayer.find()
      .sort('-performance_score')
      .limit(Number(limit))
      .select('name team role runs batting_avg strike_rate wickets performance_score fitness_score ml_predicted_price');
    res.json({ success: true, data: players });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// GET single player
router.get('/:id', async (req, res) => {
  try {
    const player = await WplPlayer.findOne({ player_id: req.params.id });
    if (!player) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: player });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

module.exports = router;
