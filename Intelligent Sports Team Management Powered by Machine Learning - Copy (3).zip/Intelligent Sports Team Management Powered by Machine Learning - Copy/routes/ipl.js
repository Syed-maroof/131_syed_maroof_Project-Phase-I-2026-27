const express = require('express');
const IplPlayer = require('../models/IplPlayer');
const router = express.Router();

// GET all IPL players (supports ?search=name&team=CSK&role=Batsman&nationality=Indian&sort=-performance_score)
router.get('/', async (req, res) => {
  try {
    const { search, team, role, nationality, sort = '-performance_score', limit = 200 } = req.query;
    const query = {};
    if (search) query.name = { $regex: search, $options: 'i' };
    if (team) query.team = { $regex: team, $options: 'i' };
    if (role) query.role = role;
    if (nationality) query.nationality = nationality;
    const players = await IplPlayer.find(query)
      .sort(sort)
      .limit(Number(limit));
    res.json({ success: true, count: players.length, data: players });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET all unique IPL teams (for dropdowns)
router.get('/meta/teams', async (req, res) => {
  try {
    const teams = await IplPlayer.distinct('team');
    res.json({ success: true, data: teams.filter(Boolean).sort() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET leaderboard: top N by performance_score
router.get('/meta/leaderboard', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const players = await IplPlayer.find()
      .sort('-performance_score')
      .limit(Number(limit))
      .select('name team role runs batting_avg strike_rate wickets performance_score fitness_score');
    res.json({ success: true, data: players });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET single IPL player by player_id
router.get('/:id', async (req, res) => {
  try {
    const player = await IplPlayer.findOne({ player_id: req.params.id });
    if (!player) return res.status(404).json({ success: false, error: 'Player not found' });
    res.json({ success: true, data: player });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST create player
router.post('/', async (req, res) => {
  try {
    const player = await IplPlayer.create(req.body);
    res.status(201).json({ success: true, data: player });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// PATCH update player
router.patch('/:id', async (req, res) => {
  try {
    const player = await IplPlayer.findOneAndUpdate(
      { player_id: req.params.id }, req.body, { new: true, runValidators: true }
    );
    if (!player) return res.status(404).json({ success: false, error: 'Player not found' });
    res.json({ success: true, data: player });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// DELETE player
router.delete('/:id', async (req, res) => {
  try {
    const result = await IplPlayer.findOneAndDelete({ player_id: req.params.id });
    if (!result) return res.status(404).json({ success: false, error: 'Player not found' });
    res.json({ success: true, message: 'Player deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
