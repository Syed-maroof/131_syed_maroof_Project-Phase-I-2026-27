require('dotenv').config();
const mongoose = require('mongoose');
const IplPlayer = require('./models/IplPlayer');

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const total = await IplPlayer.countDocuments();
  console.log('\n=== DATABASE STATUS ===');
  console.log('TOTAL PLAYERS:', total);

  const teams = await IplPlayer.aggregate([
    { $group: { _id: '$team', count: { $sum: 1 } } },
    { $sort: { _id: 1 } }
  ]);

  console.log('\n=== ALL TEAMS ===');
  teams.forEach((t, i) => {
    console.log(`${i+1}. ${t._id} → ${t.count} players`);
  });

  const roles = await IplPlayer.aggregate([
    { $group: { _id: '$role', count: { $sum: 1 } } },
    { $sort: { _id: 1 } }
  ]);
  console.log('\n=== BY ROLE ===');
  roles.forEach(r => console.log(` ${r._id}: ${r.count}`));

  console.log('\n=== ALL 150 PLAYERS ===');
  const all = await IplPlayer.find({}, 'name team role performance_score').sort({ team: 1, performance_score: -1 });
  let curTeam = '';
  all.forEach((p, i) => {
    if (p.team !== curTeam) { curTeam = p.team; console.log(`\n  --- ${curTeam} ---`); }
    console.log(`    ${p.name} | ${p.role} | Score: ${p.performance_score}`);
  });

  mongoose.disconnect();
  console.log('\n=== DONE ===');
}).catch(e => console.error(e));
