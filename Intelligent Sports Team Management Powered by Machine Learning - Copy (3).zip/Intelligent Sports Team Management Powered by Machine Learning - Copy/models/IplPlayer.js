const mongoose = require('mongoose');

const iplPlayerSchema = new mongoose.Schema({
  player_id:          { type: String, required: true, unique: true },
  name:               { type: String, required: true },
  team:               String,
  role:               String,
  nationality:        { type: String, default: 'Indian' },
  age:                Number,
  ipl_seasons:        { type: Number, default: 0 },
  matches:            { type: Number, default: 0 },
  innings_bat:        { type: Number, default: 0 },
  runs:               { type: Number, default: 0 },
  batting_avg:        Number,
  strike_rate:        Number,
  fifties:            { type: Number, default: 0 },
  hundreds:           { type: Number, default: 0 },
  fours:              { type: Number, default: 0 },
  sixes:              { type: Number, default: 0 },
  highest_score:      Number,
  innings_bowl:       { type: Number, default: 0 },
  wickets:            { type: Number, default: 0 },
  bowling_avg:        Number,
  economy:            Number,
  best_bowling:       String,
  catches:            { type: Number, default: 0 },
  fitness_score:      Number,
  recent_form:        Number,
  injury_count:       { type: Number, default: 0 },
  performance_score:  Number,

  // ── NEW ENRICHED FIELDS ─────────────────────────────────────────
  performance_label:  { type: String, enum: ['Weak', 'Average', 'Strong', 'Elite'], default: 'Average' },
  form_label:         { type: String, enum: ['Poor Form', 'Moderate Form', 'Good Form', 'Peak Form'], default: 'Moderate Form' },
  fitness_label:      { type: String, enum: ['Unfit', 'Below Average', 'Fit', 'Peak Fitness'], default: 'Fit' },
  injury_risk:        { type: String, enum: ['Low', 'Medium', 'High'], default: 'Low' },
  auction_tier:       { type: String, enum: ['Base', 'Mid', 'Top', 'Elite'], default: 'Base' },
  ml_predicted_score: Number,
  ml_predicted_price: Number,
  batting_style:      String,   // Right-hand / Left-hand
  bowling_style:      String,   // Right-arm Fast / Left-arm Spin etc.
  is_captain:         { type: Boolean, default: false },
  is_overseas:        { type: Boolean, default: false },
  impact_score:       Number,   // composite: runs + wickets contribution
  value_for_money:    Number,   // performance_score / estimated_price
}, { timestamps: true });

// Virtual: auto-compute performance_label from performance_score
iplPlayerSchema.pre('save', function (next) {
  const s = this.performance_score || 0;
  this.performance_label = s >= 90 ? 'Elite' : s >= 80 ? 'Strong' : s >= 65 ? 'Average' : 'Weak';

  const f = this.recent_form || 0;
  this.form_label = f >= 90 ? 'Peak Form' : f >= 80 ? 'Good Form' : f >= 65 ? 'Moderate Form' : 'Poor Form';

  const fit = this.fitness_score || 0;
  this.fitness_label = fit >= 92 ? 'Peak Fitness' : fit >= 82 ? 'Fit' : fit >= 70 ? 'Below Average' : 'Unfit';

  this.injury_risk = (this.injury_count || 0) >= 3 ? 'High' : (this.injury_count || 0) >= 1 ? 'Medium' : 'Low';
  this.is_overseas = this.nationality !== 'Indian';

  // Auction tier from performance_score
  this.auction_tier = s >= 92 ? 'Elite' : s >= 85 ? 'Top' : s >= 72 ? 'Mid' : 'Base';

  // Impact score: batting contribution + bowling contribution
  const batImpact = ((this.runs || 0) * 0.01) + ((this.batting_avg || 0) * 0.3) + ((this.strike_rate || 0) * 0.05);
  const bowlImpact = ((this.wickets || 0) * 0.5) + (Math.max(0, 10 - (this.economy || 8)) * 2);
  this.impact_score = Math.round((batImpact + bowlImpact) * 10) / 10;

  next();
});

module.exports = mongoose.model('IplPlayer', iplPlayerSchema);
