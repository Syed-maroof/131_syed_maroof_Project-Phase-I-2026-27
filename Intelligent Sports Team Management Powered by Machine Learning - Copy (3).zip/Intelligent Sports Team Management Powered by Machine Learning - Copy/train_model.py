"""
train_model.py
Trains ML models on IPL player data and saves:
  model/model_ipl.pkl       — RandomForest for performance_score prediction
  model/model_auction.pkl   — GradientBoosting for auction price prediction
  model/model_match.pkl     — RandomForest for match win probability
  model/scaler_ipl.pkl      — StandardScaler for features
"""

import pickle, os, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score, accuracy_score

os.makedirs("model", exist_ok=True)

# ── Load IPL CSV ──────────────────────────────────────────────────────────────
df = pd.read_csv("datasets/ipl_players.csv")
print(f"Loaded {len(df)} IPL players")

# ── Feature Engineering ───────────────────────────────────────────────────────
# Encode role
role_map = {"Batsman": 0, "Bowler": 1, "All-Rounder": 2, "Wicketkeeper-Batsman": 3}
df["role_enc"] = df["Role"].map(role_map).fillna(0)

# Encode nationality
df["nat_enc"] = (df["Nationality"] == "Indian").astype(int)

# Fill missing numerics with 0
num_cols = ["Age","Matches","Runs","Batting_Avg","Strike_Rate","Fifties","Hundreds",
            "Wickets","Economy","Bowling_Avg","Catches","Fitness_Score",
            "Recent_Form","Injury_Count","IPL_Seasons"]
for c in num_cols:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)

# ── FEATURES for performance prediction ──────────────────────────────────────
PERF_FEATURES = ["Age","Matches","Runs","Batting_Avg","Strike_Rate","Fifties","Hundreds",
                 "Wickets","Economy","Catches","Fitness_Score","Recent_Form",
                 "Injury_Count","IPL_Seasons","role_enc","nat_enc"]

PERF_FEATURES = [f for f in PERF_FEATURES if f in df.columns]
X_perf = df[PERF_FEATURES].fillna(0).values
y_perf = df["Performance_Score"].fillna(70).values

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_perf)

X_tr, X_te, y_tr, y_te = train_test_split(X_scaled, y_perf, test_size=0.2, random_state=42)

# ── Model 1: Performance Score Predictor ─────────────────────────────────────
rf_perf = RandomForestRegressor(n_estimators=200, max_depth=10, random_state=42)
rf_perf.fit(X_tr, y_tr)
pred = rf_perf.predict(X_te)
print(f"[Performance Model] MAE={mean_absolute_error(y_te,pred):.2f}  R²={r2_score(y_te,pred):.3f}")

with open("model/model_ipl.pkl","wb") as f: pickle.dump(rf_perf, f)
with open("model/scaler_ipl.pkl","wb") as f: pickle.dump(scaler, f)
# Save feature list
with open("model/features_ipl.pkl","wb") as f: pickle.dump(PERF_FEATURES, f)
print("Saved model_ipl.pkl, scaler_ipl.pkl, features_ipl.pkl")

# ── Auction price: derived target ────────────────────────────────────────────
# price = f(performance, form, fitness, role, age, injury)
df["auction_price"] = (
    df["Performance_Score"] * 0.40 +
    df["Recent_Form"] * 0.25 +
    df["Fitness_Score"] * 0.15
)
df["auction_price"] += df["role_enc"].map({2: 5, 3: 3}).fillna(0)
df["auction_price"] -= df["Injury_Count"] * 2.5
df["auction_price"] *= df["Age"].apply(lambda a: 1.1 if a<24 else 0.88 if a>34 else 1.0)
df["auction_price"] = ((df["auction_price"] - 55) * 0.22).clip(0.5, 20).round(1)

AUCTION_FEATURES = ["Age","Matches","Runs","Batting_Avg","Strike_Rate",
                    "Wickets","Economy","Fitness_Score","Recent_Form",
                    "Injury_Count","IPL_Seasons","role_enc","nat_enc","Performance_Score"]
AUCTION_FEATURES = [f for f in AUCTION_FEATURES if f in df.columns]

X_auc = df[AUCTION_FEATURES].fillna(0).values
y_auc = df["auction_price"].values

sc_auc = StandardScaler()
X_auc_sc = sc_auc.fit_transform(X_auc)
X_tr2, X_te2, y_tr2, y_te2 = train_test_split(X_auc_sc, y_auc, test_size=0.2, random_state=42)

gb_auc = GradientBoostingRegressor(n_estimators=200, max_depth=5, learning_rate=0.08, random_state=42)
gb_auc.fit(X_tr2, y_tr2)
pred2 = gb_auc.predict(X_te2)
print(f"[Auction Model]     MAE={mean_absolute_error(y_te2,pred2):.2f}  R²={r2_score(y_te2,pred2):.3f}")

with open("model/model_auction.pkl","wb") as f: pickle.dump(gb_auc, f)
with open("model/scaler_auction.pkl","wb") as f: pickle.dump(sc_auc, f)
with open("model/features_auction.pkl","wb") as f: pickle.dump(AUCTION_FEATURES, f)
print("Saved model_auction.pkl, scaler_auction.pkl, features_auction.pkl")

# ── Match win: team-level aggregated features ────────────────────────────────
teams = df["Team"].dropna().unique()
team_stats = {}
for t in teams:
    sq = df[df["Team"]==t]
    batters = sq[sq["role_enc"].isin([0,3,2])]
    bowlers = sq[sq["role_enc"].isin([1,2])]
    team_stats[t] = {
        "avg_score": sq["Performance_Score"].mean(),
        "bat_avg":   batters["Batting_Avg"].mean() if len(batters) else 25,
        "strike_rate": batters["Strike_Rate"].mean() if len(batters) else 120,
        "wickets_avg": bowlers["Wickets"].mean() if len(bowlers) else 10,
        "economy_avg": bowlers["Economy"].mean() if len(bowlers) else 8,
        "fitness":   sq["Fitness_Score"].mean(),
        "form":      sq["Recent_Form"].mean(),
    }

# Generate synthetic match samples: each row = teamA features - teamB features → win(1)/lose(0)
match_rows, match_labels = [], []
team_list = list(team_stats.keys())
for i, ta in enumerate(team_list):
    for j, tb in enumerate(team_list):
        if i==j: continue
        sa, sb = team_stats[ta], team_stats[tb]
        # Feature: differences
        feat = [
            sa["avg_score"]-sb["avg_score"],
            sa["bat_avg"]-sb["bat_avg"],
            sa["strike_rate"]-sb["strike_rate"],
            sa["wickets_avg"]-sb["wickets_avg"],
            sb["economy_avg"]-sa["economy_avg"],  # lower economy = better for A
            sa["fitness"]-sb["fitness"],
            sa["form"]-sb["form"],
        ]
        label = 1 if sa["avg_score"] > sb["avg_score"] else 0
        # Add noise variants
        for _ in range(10):
            noise = np.random.normal(0, 1.5, len(feat))
            match_rows.append(np.array(feat)+noise)
            noisy_score = (sa["avg_score"]+np.random.normal(0,3)) - (sb["avg_score"]+np.random.normal(0,3))
            match_labels.append(1 if noisy_score>0 else 0)

X_match = np.array(match_rows)
y_match = np.array(match_labels)
sc_match = StandardScaler()
X_match_sc = sc_match.fit_transform(X_match)

X_tr3, X_te3, y_tr3, y_te3 = train_test_split(X_match_sc, y_match, test_size=0.2, random_state=42)
rf_match = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42)
rf_match.fit(X_tr3, y_tr3)
acc = accuracy_score(y_te3, rf_match.predict(X_te3))
print(f"[Match Model]       Accuracy={acc:.3f}")

with open("model/model_match.pkl","wb") as f: pickle.dump(rf_match, f)
with open("model/scaler_match.pkl","wb") as f: pickle.dump(sc_match, f)
with open("model/team_stats.pkl","wb") as f: pickle.dump(team_stats, f)
print("Saved model_match.pkl, scaler_match.pkl, team_stats.pkl")

print("\n✅ All 3 ML models trained and saved to model/")
