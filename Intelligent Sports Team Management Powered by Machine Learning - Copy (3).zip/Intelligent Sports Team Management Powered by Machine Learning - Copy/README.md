# Intelligent Sports Team Management

A **full‑stack** starter project that consists of:

- **Backend** – Node.js, Express, MongoDB (via Mongoose)
- **Frontend** – React (Vite) communicating with the backend via REST API
- **Database** – MongoDB running locally (or any MongoDB URI you provide)

---

## Folder layout
```
Intelligent Sports Team Management Powered by Machine Learning - Copy/
│   README.md                 ← **this file**
│
├───backend
│   │   package.json
│   │   .env
│   │   .gitignore
│   │   server.js
│   │
│   ├───models
│   │       Player.js          ← Mongoose schema
│   │
│   └───routes
│           player.js         ← CRUD routes for players
│
└───frontend
    │   package.json
    │   vite.config.js
    │   index.html
    │   .gitignore
    │
    └───src
        │   main.jsx
        │   App.jsx
        │   index.css   ← optional styling stub
        │
        └───components
                PlayerList.jsx
                PlayerForm.jsx
```

---

## Backend setup
```powershell
cd "backend"
# Install dependencies
npm install
# Ensure MongoDB is running (local or remote). Edit .env if needed.
npm run dev   # start with nodemon
# or npm start for production
```
The API will be available at `http://localhost:5000`.

### Endpoints
| Method | Path               | Description                     |
|--------|--------------------|---------------------------------|
| GET    | `/api/health`      | Health‑check                     |
| GET    | `/api/players`     | List all players                |
| GET    | `/api/players/:id` | Get a single player by _id      |
| POST   | `/api/players`     | Create a new player             |
| PATCH  | `/api/players/:id` | Update fields (partial)         |
| DELETE | `/api/players/:id` | Delete a player                 |

---

## Frontend setup
```powershell
cd "frontend"
npm install
npm run dev   # Vite dev server on http://localhost:3000
```
During development the Vite dev server proxies `/api/*` to the backend (see `vite.config.js`).

---

## Database
The project expects a MongoDB database named **sportsdb**.
- Run `mongod` locally or with Docker:
```bash
docker run -d -p 27017:27017 --name mongodb mongo:7
```
- Adjust `backend/.env` (`MONGODB_URI`) if you use a different host or credentials.

---

## Quick test
1. Start MongoDB.
2. Run the backend (`npm run dev` in `backend`).
3. Run the frontend (`npm run dev` in `frontend`).
4. Open `http://localhost:3000` – you can add, edit, delete players; changes persist in MongoDB.

---

## Next steps
- Add authentication (JWT, Passport).
- Expand the Player schema (stats, matches, etc.).
- Write tests (Jest/Supertest for backend, React Testing Library for frontend).
- Deploy backend (Render, Railway, Fly.io) and frontend (Vercel, Netlify).

Enjoy building your intelligent sports team management system! 🚀
