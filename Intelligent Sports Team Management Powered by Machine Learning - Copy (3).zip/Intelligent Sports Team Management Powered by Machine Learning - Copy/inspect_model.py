﻿import pickle
with open("model/model_ipl.pkl","rb") as f:
    m = pickle.load(f)
with open("model/scaler_ipl.pkl","rb") as f:
    s = pickle.load(f)
print("Model:", type(m).__name__)
print("Scaler:", type(s).__name__)
try:
    print("Features:", list(m.feature_names_in_))
except:
    print("n_features:", m.n_features_in_)
try:
    print("Classes:", list(m.classes_))
except:
    pass
