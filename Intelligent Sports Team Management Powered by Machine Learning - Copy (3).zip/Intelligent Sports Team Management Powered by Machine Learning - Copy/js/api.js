/* ==========================================================================
   api.js — Frontend helper for fetching live data from the Node.js backend
   All pages import this before their own scripts.
   ========================================================================== */

const API_BASE = 'http://localhost:3000/api';

const SportsAPI = {

  // ── Generic fetch wrapper ────────────────────────────────────────────────
  async _get(url) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      const json = await res.json();
      return json.data || json;
    } catch (err) {
      console.warn(`[SportsAPI] Failed to fetch ${url}:`, err.message);
      return null;
    }
  },

  // ── Health check ─────────────────────────────────────────────────────────
  async health() {
    return this._get(`${API_BASE}/health`);
  },

  // ── IPL Players ──────────────────────────────────────────────────────────
  async getIplPlayers(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this._get(`${API_BASE}/players/ipl${qs ? '?' + qs : ''}`);
  },

  async getIplPlayer(id) {
    return this._get(`${API_BASE}/players/ipl/${id}`);
  },

  async getIplLeaderboard(limit = 10) {
    return this._get(`${API_BASE}/players/ipl/meta/leaderboard?limit=${limit}`);
  },

  async getIplTeams() {
    return this._get(`${API_BASE}/players/ipl/meta/teams`);
  },

  // ── Cricket Players ───────────────────────────────────────────────────────
  async getCricketPlayers(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this._get(`${API_BASE}/players/cricket${qs ? '?' + qs : ''}`);
  },

  async getCricketPlayer(id) {
    return this._get(`${API_BASE}/players/cricket/${id}`);
  },

  // ── Football Players ──────────────────────────────────────────────────────
  async getFootballPlayers(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this._get(`${API_BASE}/players/football${qs ? '?' + qs : ''}`);
  },

  async getFootballPlayer(id) {
    return this._get(`${API_BASE}/players/football/${id}`);
  },

  // ── Volleyball Players ────────────────────────────────────────────────────
  async getVolleyballPlayers(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this._get(`${API_BASE}/players/volleyball${qs ? '?' + qs : ''}`);
  },

  async getVolleyballPlayer(id) {
    return this._get(`${API_BASE}/players/volleyball/${id}`);
  },

  // ── Convenience: load all 4 sports in parallel ───────────────────────────
  async getAllPlayers() {
    const [ipl, cricket, football, volleyball] = await Promise.all([
      this.getIplPlayers(),
      this.getCricketPlayers(),
      this.getFootballPlayers(),
      this.getVolleyballPlayers(),
    ]);
    return {
      ipl:        Array.isArray(ipl)        ? ipl        : [],
      cricket:    Array.isArray(cricket)    ? cricket    : [],
      football:   Array.isArray(football)   ? football   : [],
      volleyball: Array.isArray(volleyball) ? volleyball : [],
    };
  },

  // ── Show a status badge in the UI ────────────────────────────────────────
  async showDBStatus() {
    const health = await this.health();
    const badge = document.getElementById('db-status-badge');
    if (!badge) return;
    if (health && health.db === 'connected') {
      badge.textContent = '🟢 DB Connected';
      badge.style.color = '#34d399';
    } else {
      badge.textContent = '🔴 DB Offline (using static data)';
      badge.style.color = '#f87171';
    }
  },
};
