require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const path     = require('path');
const http     = require('http');

const app  = express();
const PORT = process.env.PORT || 3000;
const ML_PORT = 5001;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => { console.error('🚨 MongoDB error:', err.message); process.exit(1); });

// ── IPL players API ──────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected', timestamp: new Date() });
});
app.use('/api/players', require('./routes/ipl'));
app.use('/api/wpl',     require('./routes/wpl'));

// ── ML proxy — forward to Python Flask server ────────────────────────────────
app.all(['/api/ml', '/api/ml/*'], (req, res) => {
  const mlPath = req.url.replace('/api/ml', '/ml');
  const options = {
    hostname: 'localhost',
    port: ML_PORT,
    path: mlPath,
    method: req.method,
    headers: { 'Content-Type': 'application/json' },
  };

  const proxyReq = http.request(options, proxyRes => {
    res.status(proxyRes.statusCode);
    proxyRes.setEncoding('utf8');
    let body = '';
    proxyRes.on('data', chunk => body += chunk);
    proxyRes.on('end', () => {
      try { res.json(JSON.parse(body)); }
      catch { res.send(body); }
    });
  });

  proxyReq.on('error', () => {
    res.status(503).json({ error: 'ML server offline. Run: python ml_server.py', ml_url: `http://localhost:${ML_PORT}` });
  });

  if (req.method !== 'GET' && req.body) {
    proxyReq.write(JSON.stringify(req.body));
  }
  proxyReq.end();
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.listen(PORT, () => {
  console.log(`🚀 Node server  → http://localhost:${PORT}`);
  console.log(`🤖 ML proxy     → http://localhost:${PORT}/api/ml/health`);
  console.log(`   Start ML:      python ml_server.py`);
});
