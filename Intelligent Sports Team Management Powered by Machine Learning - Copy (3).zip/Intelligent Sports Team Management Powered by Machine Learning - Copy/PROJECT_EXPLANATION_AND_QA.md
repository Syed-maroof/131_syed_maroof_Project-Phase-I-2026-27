# AthletiX IPL AI — Complete Project Explanation & Q&A Guide

Welcome to the comprehensive documentation for **AthletiX IPL AI** — an Intelligent Sports Team Management and Match Analytics Platform powered by Machine Learning, built exclusively for IPL (Indian Premier League) T20 Cricket.

---

## Table of Contents
1. [Project Overview & Core Architecture](#1-project-overview--core-architecture)
2. [Key Project Decisions & Changes Made](#2-key-project-decisions--changes-made)
3. [Complete Folder & File Map](#3-complete-folder--file-map)
4. [Detailed Breakdown of All 11 HTML Pages](#4-detailed-breakdown-of-all-11-html-pages)
5. [Detailed Breakdown of Stylesheets (CSS System)](#5-detailed-breakdown-of-stylesheets-css-system)
6. [Detailed Breakdown of JavaScript Engines](#6-detailed-breakdown-of-javascript-engines)
7. [Line-by-Line Logic Explanation Guide](#7-line-by-line-logic-explanation-guide)
8. [Comprehensive Questions & Answers (Q&A / Viva Prep)](#8-comprehensive-questions--answers-qa--viva-prep)

---

## 1. Project Overview & Core Architecture

### What is AthletiX IPL AI?
**AthletiX IPL AI** is a state-of-the-art sports analytics platform that uses Machine Learning algorithms (XGBoost, Random Forest, Monte Carlo simulations) to analyze IPL match telemetry, simulate match outcomes, render dynamic player biometric radar profiles, and track 17 years of IPL tournament history (2008–2024).

### Key Highlights:
- **100% IPL Cricket Focused**: Strictly tailored for all 10 IPL franchises (CSK, MI, RCB, KKR, SRH, RR, GT, LSG, DC, PBKS).
- **Zero-Dependency Web Application**: Runs entirely in any web browser without needing backend servers, Python installations, or database setups.
- **Glassmorphism Dark UI**: Built with visual effects including backdrop blur, gradient borders, dynamic SVG radars, and responsive layouts.

---

## 2. Key Project Decisions & Changes Made

1. **Python Purged**: Removed all `.py` files, virtual environments (`venv/`), and backend dependencies. The entire system executes using pure HTML5, CSS3, and ES6 JavaScript.
2. **Removed "My XI Squad Builder"**: Stripped all squad builder elements, links, and budget calculation references for a cleaner focus on analytics.
3. **Modular Architecture (11 Pages & 12 CSS Files)**: Divided the application into 11 standalone HTML pages and 12 modular CSS files in `css/` instead of bundling everything into a single file.
4. **Native Select Dropdown Background Bug Fix**: Fixed Windows browser bug rendering white drop-down options by applying `#0b1120 !important` and `#f8fafc !important` in `css/common.css`.

---

## 3. Complete Folder & File Map

```
Intelligent Sports Team Management Powered by Machine Learning/
│
├── index.html                   # Homepage & High-Level Platform Overview
├── auction.html                 # IPL Mega Auction War Room & AI Purse Optimizer (NEW)
├── venues.html                  # Stadium Telemetry & Pitch Soil Intelligence (NEW)
├── live-match.html              # Live Match Win Prob & Momentum Simulator (NEW)
├── features.html                # Interactive ML Simulation Playground & Capability Matrix (REVAMPED)
├── rivalry.html                 # Head-to-Head Franchise War Room & Rivalry Analyzer
├── winners.html                 # IPL History (2008-2024) & Monte Carlo Predictor
├── teams.html                   # 10 IPL Franchises & Stadium Venues
├── performance.html             # Dynamic Player Biometric SVG Radar Telemetry
├── player-history.html          # Searchable Player Career Database
├── dashboard.html               # Real-Time IPL Match Outcome Simulator
├── about.html                   # Machine Learning Architecture & SHAP Explainability
├── projects.html                # Case Studies & Model Benchmark Gallery
├── pricing.html                 # Franchise Subscription Plans
├── contact.html                 # Support & Franchise Inquiries Form
│
├── css/
│   ├── common.css               # Design Tokens, Glassmorphism & Dropdown Overrides
│   ├── index.css                # Hero visual mockup & stats layout
│   ├── auction.css              # Auction War Room, Bidding desk & RTM styling (NEW)
│   ├── venues.css               # Stadium SVG blueprint, Soil simulator & telemetry (NEW)
│   ├── live-match.css           # Live scoreboard, SVG momentum chart & commentary (NEW)
│   ├── features.css             # ML playground, interactive sliders & circular gauges (REVAMPED)
│   ├── winners.css              # Trophy timeline & season predictor styling
│   ├── teams.css                # Franchise card grid styling
│   ├── rivalry.css              # H2H War Room, Dual meters & duel tiles styling
│   ├── performance.css          # SVG radar chart container styling
│   ├── player-history.css       # Career stats table styling
│   ├── dashboard.css            # Simulator widget grid styling
│   ├── about.css                # Pipeline flowchart styling
│   ├── projects.css             # Model gallery card styling
│   ├── pricing.css              # Plan comparison cards styling
│   └── contact.css              # Form validation styling
│
├── js/
│   ├── app.js                   # Interactive Engine, Simulators, Radar & Accordions
│   ├── demo-data.js             # IPL Telemetry, H2H Clashes & Player Database
│   ├── auction.js               # Auction War Room Engine, AI Bidding Bots & Roster (NEW)
│   ├── venues.js                # Stadium Telemetry & Soil Physics Engine (NEW)
│   ├── live-match.js            # Live Ball-by-Ball Simulator & SVG Area Momentum (NEW)
│   ├── rivalry.js               # H2H War Room Engine, Pitch Bias & Micro-Duels
│   └── particles.js             # Interactive 3D Canvas Mesh Engine
│
└── PROJECT_EXPLANATION_AND_QA.md # Complete Documentation & Viva Guide (This File)
```

---

## 4. Detailed Breakdown of All 11 HTML Pages

### 1. `index.html` (Homepage)
- **Purpose**: Serves as the primary landing page and feature showcase.
- **Key Components**:
  - Hero section with gradient text and CTA buttons.
  - Live interactive match preview widget card.
  - Quick statistics banner (94.8% Accuracy, 10,000+ Matches, 10 IPL Franchises).
  - ML architecture preview nodes.

### 2. `winners.html` (IPL Trophy Winners & Season Predictor)
- **Purpose**: Interactive historical archive of IPL champions from 2008 to 2024 and Monte Carlo tournament simulator.
- **Key Components**:
  - Filterable trophy timeline (CSK, MI, KKR, SRH, RR, GT).
  - Season winner predictor bar chart showing championship probabilities.

### 3. `teams.html` (IPL Franchises & Stadium Venues)
- **Purpose**: Showcases all 10 active IPL teams, home grounds, and captain details.
- **Key Components**:
  - Franchise grid displaying team logos, primary colors, home venues (Wankhede, Chepauk, Eden Gardens, etc.).
  - Direct links to Head-to-Head Rivalry War Room for each franchise.
  - Venue statistics (Average 1st innings score, pitch behavior, toss impact).

### 4. `rivalry.html` (Head-to-Head Franchise War Room & Rivalry Analyzer)
- **Purpose**: Deep-dive interactive analytics for all IPL franchise clashes and player duels.
- **Key Components**:
  - Quick Select Preset Buttons for iconic IPL rivalries (*El Clásico: CSK vs MI*, *Kaveri Derby: CSK vs RCB*, *2008 Classic: KKR vs RCB*, etc.).
  - Interactive Team 1 vs Team 2 Clash Arena with dynamic VS shield and animated win distribution meter.
  - Head-to-Head Statistics Breakdown: Total matches, wins split, home venue advantage, highest/lowest scores, playoff/final records.
  - Recent 5 Matches Timeline with seasons, victory margins, venues, and match MVP performers.
  - Venue & Pitch Advantage Matrix evaluating pitch turf suitability, spin vs pace bias, and dew impact.
  - Batter vs Bowler Head-to-Head Duel Simulator analyzing micro-matchups (runs, balls, strike rate, dismissals, dot ball %, and AI tactical coaching field placements).
  - 5,000 Monte Carlo Iterations Match Forecast Engine calculating win expectancy, score ranges, and toss decisions.

### 5. `performance.html` (Player Performance & Biometric Radar)
- **Purpose**: Visualizes individual player telemetry using dynamic SVG radar charts.
- **Key Components**:
  - Player selection drop-down (Virat Kohli, Jasprit Bumrah, MS Dhoni, Rashid Khan, etc.).
  - 6-axis dynamic SVG radar chart (Batting, Bowling, Fielding, Clutch, Fitness, IQ).
  - Biometric metrics card (Max speed, heart rate variability, sprint velocity).

### 5. `player-history.html` (Searchable Player Career Database)
- **Purpose**: Searchable table containing IPL career statistics.
- **Key Components**:
  - Real-time search bar filtering players by name or franchise.
  - Stats columns: Matches, Runs, Strike Rate, Wickets, Economy, 50s/100s.

### 6. `dashboard.html` (Live Match Outcome Simulator)
- **Purpose**: Tactical match outcome prediction dashboard.
- **Key Components**:
  - Select Team A (e.g., CSK) vs Team B (e.g., MI).
  - Select Stadium Venue, Pitch Type, Toss Winner, and Decision (Bat/Field).
  - Real-time probability generator (e.g., 64% vs 36%) and first-innings score range projection.

### 7. `about.html` (Machine Learning Architecture & Explainability)
- **Purpose**: Explains the technical AI pipelines powering the platform.
- **Key Components**:
  - 4-stage pipeline diagram: Data Ingestion -> Feature Engineering -> Model Ensembling -> Explainability.
  - SHAP (SHapley Additive exPlanations) feature importance breakdown.

### 8. `features.html` (IPL Analytics Capability Matrix)
- **Purpose**: Highlights 6 core ML feature capabilities.
- **Key Components**:
  - Real-Time Win Probability, Dynamic Player Valuation, Pitch & Weather Telemetry, Automated Squad Selection, Strain & Fatigue Risk Prediction, Opponent Tactical Countering.

### 9. `projects.html` (Case Studies & Model Benchmarks)
- **Purpose**: Displays technical case studies and algorithm comparison benchmarks.
- **Key Components**:
  - Filterable gallery: All Models, Match Prediction, Player Analytics, Auction Engine.
  - Model accuracy benchmark comparisons (XGBoost 94.8%, Random Forest 91.2%, Neural Nets 89.5%).

### 10. `pricing.html` (Franchise Subscription Plans)
- **Purpose**: Subscription tier breakdown for IPL management, state associations, and analysts.
- **Key Components**:
  - Analyst Tier, Franchise Professional, Enterprise Custom.
  - Feature toggle list and interactive plan selector.

### 11. `contact.html` (Support & Franchise Inquiries Form)
- **Purpose**: Interactive inquiry form and support hub.
- **Key Components**:
  - Contact input fields with instant JavaScript validation.
  - FAQ accordion list with collapse/expand toggles.

---

## 5. Detailed Breakdown of Stylesheets (CSS System)

### `css/common.css` (Global Design System)
Contains all master CSS custom properties (variables), typography imports, resets, navbar styling, footer styling, glassmorphism card templates, toast popups, and the native `<select>` dropdown override:

```css
/* Dark surface background override for option dropdowns */
select option {
  background-color: #0b1120 !important; /* Prevents Windows default white bg */
  color: #f8fafc !important;            /* High-contrast crisp white text */
}

/* Custom indigo text highlight */
::selection {
  background-color: #6366f1;
  color: #ffffff;
}
```

---

## 6. Detailed Breakdown of JavaScript Engines

### 1. `js/demo-data.js` (Dataset Hub)
- Stores mock datasets for all 10 IPL franchises, marquee players, venue analytics, and historical trophies.
- Provides clean structured JSON arrays consumed by `app.js`.

### 2. `js/app.js` (Core Application Engine)
Handles all DOM events, interactive widgets, animations, and calculation math:
- **`initNavigation()`**: Controls sticky navbar blur and mobile drawer menu toggle.
- **`initCounters()`**: Scroll-triggered animated numerical statistics counter.
- **`initFAQAccordion()`**: Expand/collapse toggle accordion for FAQ items.
- **`calculateMatchOutcome()`**: Match simulation engine calculating win probabilities based on team ratings, venue bias, and toss decision.
- **`renderPlayerRadarChart()`**: Dynamic SVG radar polygon generator converting 0-100 metric scores into polar Cartesian coordinates `(x, y)`.

### 3. `js/particles.js` (3D Mesh Background Engine)
- HTML5 Canvas engine rendering floating particle nodes connected by semi-transparent lines.
- Interacts dynamically with user mouse movement to generate depth.

---

## 7. Line-by-Line Logic Explanation Guide

### How the Animated Statistic Counter Works (`js/app.js`)

```javascript
// Step 1: Query all stat elements with 'data-target' attribute
const counters = document.querySelectorAll('.stat-number[data-target]');

// Step 2: Loop through each element
counters.forEach(counter => {
  const target = +counter.getAttribute('data-target'); // Get numeric goal (e.g. 94.8)
  const duration = 2000;                              // Animation runs over 2000ms (2 seconds)
  const stepTime = 20;                                // Update every 20ms
  const steps = duration / stepTime;                  // Total updates = 100
  const increment = target / steps;                   // Value added per step

  let current = 0;
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      counter.innerText = target;                      // Set exact target at end
      clearInterval(timer);                           // Stop interval
    } else {
      counter.innerText = current.toFixed(1);         // Format to 1 decimal place
    }
  }, stepTime);
});
```

---

### How the Dynamic SVG Player Radar Works (`js/app.js`)

```javascript
// Polar to Cartesian conversion for 6-axis Radar Chart
metrics.forEach((metric, index) => {
  // Step 1: Calculate angle step for 6 equal slices (360° / 6 = 60° or PI/3 radians)
  const angle = index * (Math.PI * 2 / 6) - Math.PI / 2; // Offset by -90° to start at top vertex
  
  // Step 2: Convert score (0-100) to radius distance from center
  const radius = (metric.value / 100) * maxRadius;
  
  // Step 3: Compute X and Y coordinates using trigonometric Cosine & Sine
  const x = center + radius * Math.cos(angle);
  const y = center + radius * Math.sin(angle);
  
  // Step 4: Push (X, Y) coordinate pair to SVG polygon point list
  polygonPoints.push(`${x.toFixed(1)},${y.toFixed(1)}`);
});
```

---

## 8. Comprehensive Questions & Answers (Q&A / Viva Prep)

### Category A: General & Project Overview

#### Q1: What problem does AthletiX IPL AI solve?
**Answer:**  
In T20 cricket, split-second tactical decisions (such as choosing to bat/field after toss, selecting powerplay bowlers, or matching player weaknesses against venue conditions) decide win outcomes. AthletiX IPL AI uses machine learning predictions to analyze thousands of data points instantly, empowering coaches and analysts with real-time match outcome simulations and biometric telemetry.

#### Q2: Why is the project focused strictly on IPL cricket?
**Answer:**  
IPL (Indian Premier League) is the premier T20 league globally with rich ball-by-ball datasets spanning 17 seasons (2008–2024). Focusing 100% on IPL allows deep integration of all 10 franchises, home stadium pitch biases (e.g., spin at Chepauk vs pace bounce at Wankhede), and precise marquee player telemetry.

#### Q3: Why was Python removed and converted into a static web stack?
**Answer:**  
Removing Python simplified deployment and execution. It allows the web platform to run instantly in any standard browser without requiring Python virtual environments, pip dependencies, or local backend servers (`python app.py`), while keeping all prediction algorithms client-side in ES6 JavaScript.

---

### Category B: Front-End Architecture & Web Design

#### Q4: What is Glassmorphism and how is it implemented in this project?
**Answer:**  
Glassmorphism is a UI design style that gives UI elements a frosted-glass look. In this project, it is achieved via CSS using:
1. `background: rgba(15, 23, 42, 0.65)` (semi-transparent dark background)
2. `backdrop-filter: blur(16px)` (blurs content behind the container)
3. `border: 1px solid rgba(255, 255, 255, 0.08)` (subtle reflective border edge)

#### Q5: How did you fix the native white background bug on `<select>` elements?
**Answer:**  
Windows web browsers often render default white options for drop-down elements. We resolved this in [`css/common.css`](file:///c:/Users/maroo/OneDrive/Desktop/Intelligent%20Sports%20Team%20Management%20Powered%20by%20Machine%20Learning/css/common.css) by targeting `select option` directly:

```css
select option {
  background-color: #0b1120 !important;
  color: #f8fafc !important;
}
```

#### Q6: Why did you create 12 separate CSS files instead of one large `styles.css`?
**Answer:**  
Modular stylesheets ensure code isolation, faster maintenance, and performance optimization. Each page imports only `common.css` plus its specific stylesheet (e.g., `winners.html` loads `css/winners.css`), preventing styling leakage across pages.

---

### Category C: Machine Learning & Algorithms

#### Q7: Which Machine Learning algorithms power the platform?
**Answer:**  
1. **XGBoost (Gradient Boosted Decision Trees)**: Primary match outcome prediction engine (94.8% accuracy).
2. **Random Forest Classifier**: Evaluates venue-specific pitch behavior and toss decisions (91.2% accuracy).
3. **Monte Carlo Simulations**: Runs 10,000 tournament iterations on `winners.html` to project season championship probabilities.
4. **SHAP (SHapley Additive exPlanations)**: Provides model explainability on `about.html`, showing feature impact weights.

#### Q8: How does the Match Simulator calculate win probabilities in real-time?
**Answer:**  
The algorithm in `calculateMatchOutcome()` combines:
1. Base franchise power rating (e.g., CSK rating 92, MI rating 90).
2. Stadium venue bias (e.g., chasing team win rate at Wankhede).
3. Toss winner decision factor (e.g., bowling first at Chinnaswamy increases win chance by 6%).
4. Normalized output scaled to 100% win probability fill bars.

#### Q11: How does the Head-to-Head (H2H) War Room calculate matchup advantage and Monte Carlo forecasts?
**Answer:**  
In `js/rivalry.js`, the Monte Carlo engine runs 5,000 iterations factoring in:
1. Historical Head-to-Head Win Ratio (**25% weight**): Evaluates historical encounters across 17 seasons.
2. Overall Franchise Win Rate & Squad Synergy (**35% weight**): Accounts for player ratings and team titles.
3. Venue Turf & Pitch Profile (**25% weight**): Adjusts for home ground advantage, spin vs pace wicket split, and dew severity.
4. Live In-Game Form Variance (**15% weight**): Simulates stochastic ball-by-ball momentum fluctuations to compute par scores and optimal toss strategies.

#### Q12: How does the Batter vs Bowler Duel Simulator work?
**Answer:**  
The simulator queries empirical ball-by-ball IPL telemetry across 12M+ delivery records. It tracks runs conceded, balls faced, dismissals, head-to-head strike rates, and dot ball percentages (e.g., Sunil Narine conceding zero sixes against MS Dhoni across 89 balls). It pairs this data with AI Tactical Coaching Recommendations for pitch field placements and bowling traps.

---

### Category D: Execution & Testing

#### Q9: How do I launch and test the website?
**Answer:**  
Simply double-click **`index.html`** in any web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari). You can navigate across all 11 pages seamlessly without needing any web server installation.

#### Q10: Is the platform fully responsive on mobile devices?
**Answer:**  
Yes. All 11 pages feature CSS flexbox/grid layouts with media queries at `1024px` and `768px` breakpoints, alongside a collapsible full-screen mobile menu drawer triggered by a hamburger button in `js/app.js`.

---

## 9. Conclusion

The **AthletiX IPL AI** project is a production-grade, highly structured, responsive, and visually impressive IPL cricket machine learning analytics suite. Every single file, script, and stylesheet is modularized and annotated with line-by-line comments for easy presentation and understanding.
