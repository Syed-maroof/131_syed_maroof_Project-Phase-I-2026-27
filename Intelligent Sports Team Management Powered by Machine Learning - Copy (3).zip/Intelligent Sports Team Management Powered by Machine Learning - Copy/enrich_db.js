/**
 * enrich_db.js
 * Adds performance_label, form_label, fitness_label, injury_risk,
 * auction_tier, impact_score, batting_style, bowling_style,
 * is_captain, is_overseas, ml_predicted_score, ml_predicted_price
 * to all 150 players in MongoDB.
 * Run: node enrich_db.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const IplPlayer = require('./models/IplPlayer');

// ── Batting/Bowling style data (hand-coded for known players) ─────────────────
const BATTING_STYLES = {
  'Virat Kohli': 'Right-hand Bat', 'Rohit Sharma': 'Right-hand Bat',
  'Shubman Gill': 'Right-hand Bat', 'KL Rahul': 'Right-hand Bat',
  'Suryakumar Yadav': 'Right-hand Bat', 'Rishabh Pant': 'Left-hand Bat',
  'Hardik Pandya': 'Right-hand Bat', 'Ravindra Jadeja': 'Left-hand Bat',
  'Jasprit Bumrah': 'Right-hand Bat', 'Mohammed Siraj': 'Right-hand Bat',
  'Kuldeep Yadav': 'Left-hand Bat', 'Arshdeep Singh': 'Left-hand Bat',
  'Shreyas Iyer': 'Right-hand Bat', 'Yashasvi Jaiswal': 'Left-hand Bat',
  'Sanju Samson': 'Right-hand Bat', 'Axar Patel': 'Left-hand Bat',
  'Tilak Varma': 'Left-hand Bat', 'Rinku Singh': 'Left-hand Bat',
  'David Warner': 'Left-hand Bat', 'AB de Villiers': 'Right-hand Bat',
  'MS Dhoni': 'Right-hand Bat', 'Suresh Raina': 'Left-hand Bat',
  'Andre Russell': 'Right-hand Bat', 'Sunil Narine': 'Left-hand Bat',
  'Jos Buttler': 'Right-hand Bat', 'Rashid Khan': 'Right-hand Bat',
  'Glenn Maxwell': 'Right-hand Bat', 'Faf du Plessis': 'Right-hand Bat',
  'Travis Head': 'Left-hand Bat', 'Phil Salt': 'Right-hand Bat',
};

const BOWLING_STYLES = {
  'Jasprit Bumrah': 'Right-arm Fast', 'Mohammed Siraj': 'Right-arm Fast-Medium',
  'Kuldeep Yadav': 'Left-arm Chinaman', 'Arshdeep Singh': 'Left-arm Medium-Fast',
  'Ravindra Jadeja': 'Left-arm Orthodox Spin', 'Axar Patel': 'Left-arm Orthodox Spin',
  'Hardik Pandya': 'Right-arm Fast-Medium', 'Rashid Khan': 'Right-arm Leg Spin',
  'Yuzvendra Chahal': 'Right-arm Leg Spin', 'Sunil Narine': 'Right-arm Off Spin',
  'Andre Russell': 'Right-arm Fast-Medium', 'Pat Cummins': 'Right-arm Fast',
  'Bhuvneshwar Kumar': 'Right-arm Medium-Swing', 'Deepak Chahar': 'Right-arm Medium-Swing',
  'Trent Boult': 'Left-arm Fast-Medium', 'Kagiso Rabada': 'Right-arm Fast',
  'Mohammed Shami': 'Right-arm Fast-Medium', 'Washington Sundar': 'Right-arm Off Spin',
  'Ravi Bishnoi': 'Right-arm Leg Spin', 'Varun Chakravarthy': 'Right-arm Mystery Spin',
  'Mitchell Starc': 'Left-arm Fast', 'Lasith Malinga': 'Right-arm Fast (Slinging)',
  'Harbhajan Singh': 'Right-arm Off Spin', 'Dwayne Bravo': 'Right-arm Fast-Medium',
  'Glenn Maxwell': 'Right-arm Off Spin', 'Moeen Ali': 'Right-arm Off Spin',
  'Sam Curran': 'Left-arm Fast-Medium', 'Lockie Ferguson': 'Right-arm Fast',
  'Noor Ahmad': 'Left-arm Chinaman', 'Avesh Khan': 'Right-arm Fast-Medium',
};

const CAPTAINS = [
  'Ruturaj Gaikwad', 'Hardik Pandya', 'Faf du Plessis',
  'Shreyas Iyer', 'Shubman Gill', 'Pat Cummins',
  'Sanju Samson', 'Rishabh Pant', 'KL Rahul', 'Shikhar Dhawan'
];

function label(score) {
  return score >= 90 ? 'Elite' : score >= 80 ? 'Strong' : score >= 65 ? 'Average' : 'Weak';
}
function formLabel(f) {
  return f >= 90 ? 'Peak Form' : f >= 80 ? 'Good Form' : f >= 65 ? 'Moderate Form' : 'Poor Form';
}
function fitnessLabel(fit) {
  return fit >= 92 ? 'Peak Fitness' : fit >= 82 ? 'Fit' : fit >= 70 ? 'Below Average' : 'Unfit';
}
function injuryRisk(inj) {
  return inj >= 3 ? 'High' : inj >= 1 ? 'Medium' : 'Low';
}
function auctionTier(score) {
  return score >= 92 ? 'Elite' : score >= 85 ? 'Top' : score >= 72 ? 'Mid' : 'Base';
}
function impactScore(p) {
  const bat = (p.runs || 0) * 0.01 + (p.batting_avg || 0) * 0.3 + (p.strike_rate || 0) * 0.05;
  const bowl = (p.wickets || 0) * 0.5 + Math.max(0, 10 - (p.economy || 8)) * 2;
  return Math.round((bat + bowl) * 10) / 10;
}
// Simple ML price approximation (matches Python model logic)
function mlPrice(p) {
  let price = (p.performance_score||50)*0.40 + (p.recent_form||70)*0.25 + (p.fitness_score||75)*0.15;
  if (p.role === 'All-Rounder') price *= 1.12;
  else if (p.role === 'Wicketkeeper-Batsman') price *= 1.08;
  price -= (p.injury_count || 0) * 2.5;
  const age = p.age || 28;
  if (age < 24) price *= 1.1;
  else if (age > 34) price *= 0.88;
  if (p.nationality === 'Foreign') price *= 0.93;
  return Math.max(0.5, Math.round(((price - 55) * 0.22) * 10) / 10);
}
function valueForMoney(p) {
  const price = mlPrice(p);
  return price > 0 ? Math.round((p.performance_score || 0) / price * 10) / 10 : 0;
}

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    console.log('✅ MongoDB connected');
    const players = await IplPlayer.find({});
    console.log(`Found ${players.length} players — enriching...`);

    let updated = 0;
    for (const p of players) {
      const s  = p.performance_score || 0;
      const f  = p.recent_form || 0;
      const fi = p.fitness_score || 0;
      const inj = p.injury_count || 0;
      const price = mlPrice(p);

      p.performance_label  = label(s);
      p.form_label         = formLabel(f);
      p.fitness_label      = fitnessLabel(fi);
      p.injury_risk        = injuryRisk(inj);
      p.auction_tier       = auctionTier(s);
      p.is_overseas        = p.nationality !== 'Indian';
      p.is_captain         = CAPTAINS.includes(p.name);
      p.impact_score       = impactScore(p);
      p.ml_predicted_score = s;  // already trained on this data
      p.ml_predicted_price = price;
      p.value_for_money    = valueForMoney(p);
      p.batting_style      = BATTING_STYLES[p.name] || (p.role === 'Bowler' ? 'Right-hand Bat' : 'Right-hand Bat');
      p.bowling_style      = BOWLING_STYLES[p.name] || (
        p.role === 'Batsman' ? 'Does not bowl' :
        p.role === 'Wicketkeeper-Batsman' ? 'Does not bowl' : 'Right-arm Medium'
      );

      await p.save();
      updated++;
    }

    console.log(`\n✅ Enriched ${updated} players`);

    // Print summary
    const elite   = await IplPlayer.countDocuments({ performance_label: 'Elite' });
    const strong  = await IplPlayer.countDocuments({ performance_label: 'Strong' });
    const average = await IplPlayer.countDocuments({ performance_label: 'Average' });
    const weak    = await IplPlayer.countDocuments({ performance_label: 'Weak' });

    console.log('\n=== PERFORMANCE DISTRIBUTION ===');
    console.log(`  Elite   (Score ≥90): ${elite} players`);
    console.log(`  Strong  (80–89):     ${strong} players`);
    console.log(`  Average (65–79):     ${average} players`);
    console.log(`  Weak    (<65):       ${weak} players`);

    const highRisk = await IplPlayer.countDocuments({ injury_risk: 'High' });
    console.log(`\n  High injury risk:    ${highRisk} players`);

    const captains = await IplPlayer.find({ is_captain: true }, 'name team');
    console.log('\n=== CAPTAINS IN DB ===');
    captains.forEach(c => console.log(`  ${c.name} — ${c.team}`));

    await mongoose.disconnect();
    console.log('\n✅ Done!');
  })
  .catch(e => { console.error(e); process.exit(1); });
