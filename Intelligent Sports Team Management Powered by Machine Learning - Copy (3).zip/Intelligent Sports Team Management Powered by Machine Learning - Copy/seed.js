/**
 * seed.js  —  Seeds both IPL (150) and WPL (90) players into MongoDB
 * Run: node seed.js
 */
require('dotenv').config();
const mongoose  = require('mongoose');
const fs        = require('fs');
const path      = require('path');
const IplPlayer = require('./models/IplPlayer');
const WplPlayer = require('./models/WplPlayer');

// ── Batting/Bowling style maps ────────────────────────────────────────────────
const BAT = {
  'Virat Kohli':'Right-hand Bat','Rohit Sharma':'Right-hand Bat','Shubman Gill':'Right-hand Bat',
  'KL Rahul':'Right-hand Bat','Suryakumar Yadav':'Right-hand Bat','Rishabh Pant':'Left-hand Bat',
  'Hardik Pandya':'Right-hand Bat','Ravindra Jadeja':'Left-hand Bat','Jasprit Bumrah':'Right-hand Bat',
  'Yashasvi Jaiswal':'Left-hand Bat','Sanju Samson':'Right-hand Bat','Axar Patel':'Left-hand Bat',
  'Tilak Varma':'Left-hand Bat','Rinku Singh':'Left-hand Bat','David Warner':'Left-hand Bat',
  'AB de Villiers':'Right-hand Bat','MS Dhoni':'Right-hand Bat','Suresh Raina':'Left-hand Bat',
  'Andre Russell':'Right-hand Bat','Sunil Narine':'Left-hand Bat','Jos Buttler':'Right-hand Bat',
  'Rashid Khan':'Right-hand Bat','Glenn Maxwell':'Right-hand Bat','Faf du Plessis':'Right-hand Bat',
  'Travis Head':'Left-hand Bat','Phil Salt':'Right-hand Bat','Quinton de Kock':'Left-hand Bat',
  'Nicholas Pooran':'Left-hand Bat','David Miller':'Left-hand Bat','Ruturaj Gaikwad':'Right-hand Bat',
  'Shikhar Dhawan':'Left-hand Bat','Prithvi Shaw':'Right-hand Bat','Ishan Kishan':'Left-hand Bat',
  'Liam Livingstone':'Right-hand Bat','Tim David':'Right-hand Bat','Shimron Hetmyer':'Left-hand Bat',
  'Tristan Stubbs':'Right-hand Bat','Finn Allen':'Right-hand Bat','Rahmanullah Gurbaz':'Right-hand Bat',
  // WPL
  'Smriti Mandhana':'Left-hand Bat','Shafali Verma':'Right-hand Bat','Harmanpreet Kaur':'Right-hand Bat',
  'Jemimah Rodrigues':'Right-hand Bat','Deepti Sharma':'Right-hand Bat','Richa Ghosh':'Right-hand Bat',
  'Yastika Bhatia':'Left-hand Bat','Beth Mooney':'Left-hand Bat','Alyssa Healy':'Right-hand Bat',
  'Alice Capsey':'Right-hand Bat','Nat Sciver-Brunt':'Right-hand Bat','Hayley Matthews':'Right-hand Bat',
  'Ellyse Perry':'Right-hand Bat','Sophie Devine':'Right-hand Bat','Grace Harris':'Right-hand Bat',
  'Meg Lanning':'Right-hand Bat','Deandra Dottin':'Right-hand Bat','Kiran Navgire':'Right-hand Bat',
  'Heather Knight':'Right-hand Bat','Danni Wyatt':'Right-hand Bat','Ashleigh Gardner':'Right-hand Bat',
  'Dayalan Hemalatha':'Right-hand Bat','Chamari Athapaththu':'Left-hand Bat','Tahlia McGrath':'Right-hand Bat',
  'Amelia Kerr':'Right-hand Bat','Chloe Tryon':'Left-hand Bat','Laura Wolvaardt':'Right-hand Bat',
};

const BOWL = {
  'Jasprit Bumrah':'Right-arm Fast','Mohammed Siraj':'Right-arm Fast-Medium',
  'Kuldeep Yadav':'Left-arm Chinaman','Arshdeep Singh':'Left-arm Medium-Fast',
  'Ravindra Jadeja':'Left-arm Orthodox Spin','Axar Patel':'Left-arm Orthodox Spin',
  'Hardik Pandya':'Right-arm Fast-Medium','Rashid Khan':'Right-arm Leg Spin',
  'Yuzvendra Chahal':'Right-arm Leg Spin','Sunil Narine':'Right-arm Off Spin',
  'Andre Russell':'Right-arm Fast-Medium','Pat Cummins':'Right-arm Fast',
  'Bhuvneshwar Kumar':'Right-arm Medium Swing','Deepak Chahar':'Right-arm Medium Swing',
  'Trent Boult':'Left-arm Fast-Medium','Kagiso Rabada':'Right-arm Fast',
  'Mohammed Shami':'Right-arm Fast-Medium','Washington Sundar':'Right-arm Off Spin',
  'Ravi Bishnoi':'Right-arm Leg Spin','Varun Chakravarthy':'Right-arm Mystery Spin',
  'Mitchell Starc':'Left-arm Fast','Lasith Malinga':'Right-arm Fast (Slinging)',
  'Harbhajan Singh':'Right-arm Off Spin','Glenn Maxwell':'Right-arm Off Spin',
  'Sam Curran':'Left-arm Fast-Medium','Lockie Ferguson':'Right-arm Fast',
  'Noor Ahmad':'Left-arm Chinaman','Shardul Thakur':'Right-arm Fast-Medium',
  // WPL
  'Renuka Singh Thakur':'Right-arm Fast-Medium','Deepti Sharma':'Right-arm Off Spin',
  'Sophie Ecclestone':'Left-arm Orthodox Spin','Radha Yadav':'Left-arm Wrist Spin',
  'Ellyse Perry':'Right-arm Fast-Medium','Nat Sciver-Brunt':'Right-arm Fast-Medium',
  'Hayley Matthews':'Right-arm Off Spin','Amelia Kerr':'Right-arm Leg Spin',
  'Marizanne Kapp':'Right-arm Fast-Medium','Alice Capsey':'Right-arm Off Spin',
  'Heather Knight':'Right-arm Off Spin','Megan Schutt':'Right-arm Fast-Medium',
  'Shabnim Ismail':'Right-arm Fast','Anjali Sarvani':'Right-arm Fast-Medium',
  'Pooja Vastrakar':'Right-arm Fast-Medium','Poonam Yadav':'Right-arm Leg Spin',
  'Ashleigh Gardner':'Right-arm Off Spin','Tahlia McGrath':'Right-arm Fast-Medium',
  'Kim Garth':'Right-arm Fast-Medium','Tanuja Kanwar':'Right-arm Off Spin',
  'Lea Tahuhu':'Right-arm Fast','Meghna Singh':'Right-arm Fast-Medium',
  'Alana King':'Right-arm Leg Spin','Kate Cross':'Right-arm Fast-Medium',
  'Krunal Pandya':'Left-arm Orthodox Spin','Deepak Hooda':'Right-arm Off Spin',
  'Dhara Gujjar':'Right-arm Fast-Medium','Saika Ishaque':'Left-arm Fast-Medium',
  'Mansi Joshi':'Right-arm Fast-Medium','Minnu Mani':'Right-arm Off Spin',
  'Priya Mishra':'Right-arm Leg Spin','Poonam Raut':'Does not bowl',
  'Ayabonga Khaka':'Right-arm Fast-Medium','Hannah Darlington':'Right-arm Fast-Medium',
  'Nida Dar':'Right-arm Off Spin','Sune Luus':'Right-arm Off Spin',
  'Jhulan Goswami':'Right-arm Fast','Jasy Sansoni':'Right-arm Fast-Medium',
  'Falak Naz':'Right-arm Fast','Gouher Sultana':'Right-arm Fast-Medium',
};

const IPL_CAPTAINS = ['Ruturaj Gaikwad','Hardik Pandya','Faf du Plessis','Shreyas Iyer','Shubman Gill','Pat Cummins','Sanju Samson','Rishabh Pant','KL Rahul','Shikhar Dhawan'];
const WPL_CAPTAINS = ['Smriti Mandhana','Harmanpreet Kaur','Deepti Sharma','Meg Lanning','Harleen Deol','Beth Mooney'];

// ── Helpers ───────────────────────────────────────────────────────────────────
function parseCSV(file) {
  const lines = fs.readFileSync(file,'utf8').trim().split('\n').map(l=>l.replace(/\r/g,''));
  const h = lines[0].split(',');
  return lines.slice(1).map(line => {
    const v = line.split(','), o = {};
    h.forEach((k,i) => o[k.trim()] = (v[i]||'').trim());
    return o;
  });
}
const n = v => { const x=parseFloat(v); return isNaN(x)?0:x; };

function labels(s,f,fi,inj) {
  return {
    performance_label: s>=90?'Elite':s>=80?'Strong':s>=65?'Average':'Weak',
    form_label:        f>=90?'Peak Form':f>=80?'Good Form':f>=65?'Moderate Form':'Poor Form',
    fitness_label:     fi>=92?'Peak Fitness':fi>=82?'Fit':fi>=70?'Below Average':'Unfit',
    injury_risk:       inj>=3?'High':inj>=1?'Medium':'Low',
    auction_tier:      s>=92?'Elite':s>=85?'Top':s>=72?'Mid':'Base',
  };
}

function mlPrice(s,f,fi,inj,age,role,nat) {
  let p = s*0.40 + f*0.25 + fi*0.15;
  if (role==='All-Rounder') p*=1.12;
  else if (role==='Wicketkeeper-Batsman') p*=1.08;
  p -= inj*2.5;
  if (age<24) p*=1.1; else if (age>34) p*=0.88;
  if (nat==='Foreign') p*=0.93;
  return Math.max(0.5, Math.round(((p-55)*0.22)*10)/10);
}

function impact(runs,bat_avg,sr,wickets,economy) {
  return Math.round(((runs*0.01)+(bat_avg*0.3)+(sr*0.05)+(wickets*0.5)+Math.max(0,10-economy)*2)*10)/10;
}

function toIPL(r) {
  const s=n(r.Performance_Score),f=n(r.Recent_Form),fi=n(r.Fitness_Score),inj=n(r.Injury_Count),age=n(r.Age);
  const price=mlPrice(s,f,fi,inj,age,r.Role,r.Nationality);
  const lab=labels(s,f,fi,inj);
  const name=r.Player_Name;
  return {
    player_id:r.Player_ID, name, team:r.Team, role:r.Role,
    nationality:r.Nationality||'Indian', age,
    ipl_seasons:n(r.IPL_Seasons), matches:n(r.Matches), innings_bat:n(r.Innings_Bat),
    runs:n(r.Runs), batting_avg:n(r.Batting_Avg), strike_rate:n(r.Strike_Rate),
    fifties:n(r.Fifties), hundreds:n(r.Hundreds), fours:n(r.Fours), sixes:n(r.Sixes),
    highest_score:n(r.Highest_Score), innings_bowl:n(r.Innings_Bowl), wickets:n(r.Wickets),
    bowling_avg:n(r.Bowling_Avg), economy:n(r.Economy), best_bowling:r.Best_Bowling||'0/0',
    catches:n(r.Catches), fitness_score:fi, recent_form:f, injury_count:inj,
    performance_score:s, ...lab,
    is_captain:IPL_CAPTAINS.includes(name), is_overseas:r.Nationality!=='Indian',
    batting_style:BAT[name]||'Right-hand Bat',
    bowling_style:BOWL[name]||(r.Role==='Batsman'||r.Role==='Wicketkeeper-Batsman'?'Does not bowl':'Right-arm Medium'),
    impact_score:impact(n(r.Runs),n(r.Batting_Avg),n(r.Strike_Rate),n(r.Wickets),n(r.Economy)),
    ml_predicted_score:s, ml_predicted_price:price,
    value_for_money:price>0?Math.round((s/price)*10)/10:0,
  };
}

function toWPL(r) {
  const s=n(r.Performance_Score),f=n(r.Recent_Form),fi=n(r.Fitness_Score),inj=n(r.Injury_Count),age=n(r.Age);
  const price=mlPrice(s,f,fi,inj,age,r.Role,r.Nationality);
  const lab=labels(s,f,fi,inj);
  const name=r.Player_Name;
  return {
    player_id:r.Player_ID, name, team:r.Team, role:r.Role,
    nationality:r.Nationality||'Indian', age,
    wpl_seasons:n(r.WPL_Seasons), matches:n(r.Matches), innings_bat:n(r.Innings_Bat),
    runs:n(r.Runs), batting_avg:n(r.Batting_Avg), strike_rate:n(r.Strike_Rate),
    fifties:n(r.Fifties), hundreds:n(r.Hundreds), fours:n(r.Fours), sixes:n(r.Sixes),
    highest_score:n(r.Highest_Score), innings_bowl:n(r.Innings_Bowl), wickets:n(r.Wickets),
    bowling_avg:n(r.Bowling_Avg), economy:n(r.Economy), best_bowling:r.Best_Bowling||'0/0',
    catches:n(r.Catches), fitness_score:fi, recent_form:f, injury_count:inj,
    performance_score:s, ...lab,
    is_captain:WPL_CAPTAINS.includes(name), is_overseas:r.Nationality!=='Indian',
    batting_style:BAT[name]||'Right-hand Bat',
    bowling_style:BOWL[name]||(r.Role==='Batsman'||r.Role==='Wicketkeeper-Batsman'?'Does not bowl':'Right-arm Medium'),
    impact_score:impact(n(r.Runs),n(r.Batting_Avg),n(r.Strike_Rate),n(r.Wickets),n(r.Economy)),
    ml_predicted_score:s, ml_predicted_price:price,
    value_for_money:price>0?Math.round((s/price)*10)/10:0,
    league:'WPL',
  };
}

async function seedCollection(Model, rows, transformer, label) {
  let ok=0, fail=0;
  for (const row of rows) {
    try {
      const doc = transformer(row);
      await Model.findOneAndUpdate({ player_id:doc.player_id }, doc, { upsert:true, new:true, setDefaultsOnInsert:true });
      ok++;
    } catch(e) { console.error(`  ❌ ${row.Player_ID} ${row.Player_Name}: ${e.message}`); fail++; }
  }
  console.log(`  ✅ ${label}: ${ok} upserted, ${fail} failed`);
}

// ── Main ──────────────────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser:true, useUnifiedTopology:true })
  .then(async () => {
    console.log('✅ MongoDB connected\n');
    const dir = path.join(__dirname,'datasets');

    console.log('🏏 Seeding IPL players...');
    await seedCollection(IplPlayer, parseCSV(path.join(dir,'ipl_players.csv')), toIPL, 'IPL');

    console.log('👩 Seeding WPL players...');
    await seedCollection(WplPlayer, parseCSV(path.join(dir,'wpl_players.csv')), toWPL, 'WPL');

    // ── Print full summary ────────────────────────────────────────────────────
    const iplTotal  = await IplPlayer.countDocuments();
    const wplTotal  = await WplPlayer.countDocuments();

    console.log('\n╔══════════════════════════════════════════╗');
    console.log('║           DATABASE SUMMARY               ║');
    console.log('╠══════════════════════════════════════════╣');
    console.log(`║  IPL Players : ${String(iplTotal).padEnd(27)}║`);
    console.log(`║  WPL Players : ${String(wplTotal).padEnd(27)}║`);
    console.log(`║  TOTAL       : ${String(iplTotal+wplTotal).padEnd(27)}║`);
    console.log('╠══════════════════════════════════════════╣');

    // IPL teams
    const iplTeams = await IplPlayer.aggregate([
      {$group:{_id:'$team',count:{$sum:1},avg:{$avg:'$performance_score'}}},
      {$sort:{avg:-1}}
    ]);
    console.log('║  IPL TEAMS                               ║');
    for (const t of iplTeams) {
      const line = `║   ${(t._id||'').substring(0,24).padEnd(24)} ${String(t.count).padStart(2)} pl  avg:${Math.round(t.avg)}`;
      console.log(line.padEnd(43)+'║');
    }
    console.log('╠══════════════════════════════════════════╣');

    // WPL teams
    const wplTeams = await WplPlayer.aggregate([
      {$group:{_id:'$team',count:{$sum:1},avg:{$avg:'$performance_score'}}},
      {$sort:{avg:-1}}
    ]);
    console.log('║  WPL TEAMS                               ║');
    for (const t of wplTeams) {
      const line = `║   ${(t._id||'').substring(0,24).padEnd(24)} ${String(t.count).padStart(2)} pl  avg:${Math.round(t.avg)}`;
      console.log(line.padEnd(43)+'║');
    }
    console.log('╠══════════════════════════════════════════╣');

    // All WPL players
    console.log('║  ALL WPL PLAYERS                         ║');
    const wplAll = await WplPlayer.find({}, 'name team role performance_score performance_label')
      .sort({ team:1, performance_score:-1 });
    let cur='';
    for (const p of wplAll) {
      if (p.team!==cur) { cur=p.team; console.log(`║  ── ${(cur||'').substring(0,38).padEnd(38)}║`); }
      const icon=p.performance_label==='Elite'?'⭐':p.performance_label==='Strong'?'🟠':p.performance_label==='Average'?'🟡':'⚫';
      const line=`║    ${p.name.padEnd(30)} ${(p.role||'').substring(0,16).padEnd(16)} ${icon}${p.performance_score}`;
      console.log(line.padEnd(43)+'║');
    }
    console.log('╚══════════════════════════════════════════╝');
    console.log('\n✅ Seed complete!');
    await mongoose.disconnect();
  })
  .catch(e => { console.error('🚨', e.message); process.exit(1); });
