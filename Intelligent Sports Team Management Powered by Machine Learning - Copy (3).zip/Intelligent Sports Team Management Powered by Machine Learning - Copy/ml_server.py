"""
ml_server.py — Flask ML API (port 5001)
Endpoints:
  POST /ml/predict-score     → predict performance score for a player
  POST /ml/predict-auction   → predict auction price for a player
  POST /ml/predict-match     → predict win probability for two teams
  POST /ml/predict-all       → batch predict scores for all players
  GET  /ml/health            → health check
"""

import pickle, os, traceback
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")

def load(name):
    with open(os.path.join(MODEL_DIR, name), "rb") as f:
        return pickle.load(f)

# Load all models once at startup
print("Loading ML models...")
MODEL_PERF    = load("model_ipl.pkl")
SCALER_PERF   = load("scaler_ipl.pkl")
FEATURES_PERF = load("features_ipl.pkl")

MODEL_AUCTION    = load("model_auction.pkl")
SCALER_AUCTION   = load("scaler_auction.pkl")
FEATURES_AUCTION = load("features_auction.pkl")

MODEL_MATCH  = load("model_match.pkl")
SCALER_MATCH = load("scaler_match.pkl")
TEAM_STATS   = load("team_stats.pkl")
print("✅ All 3 ML models loaded")

ROLE_MAP = {"Batsman": 0, "Bowler": 1, "All-Rounder": 2, "Wicketkeeper-Batsman": 3}

def player_to_perf_vec(p):
    """Convert player dict to performance feature vector."""
    return [
        float(p.get("Age", 28)),
        float(p.get("Matches", p.get("matches", 0))),
        float(p.get("Runs", p.get("runs", 0))),
        float(p.get("Batting_Avg", p.get("batting_avg", 25))),
        float(p.get("Strike_Rate", p.get("strike_rate", 120))),
        float(p.get("Fifties", p.get("fifties", 0))),
        float(p.get("Hundreds", p.get("hundreds", 0))),
        float(p.get("Wickets", p.get("wickets", 0))),
        float(p.get("Economy", p.get("economy", 8))),
        float(p.get("Catches", p.get("catches", 0))),
        float(p.get("Fitness_Score", p.get("fitness_score", 75))),
        float(p.get("Recent_Form", p.get("recent_form", 70))),
        float(p.get("Injury_Count", p.get("injury_count", 0))),
        float(p.get("IPL_Seasons", p.get("ipl_seasons", 1))),
        float(ROLE_MAP.get(p.get("Role", p.get("role", "Batsman")), 0)),
        1.0 if p.get("Nationality", p.get("nationality", "Indian")) == "Indian" else 0.0,
    ]

def player_to_auction_vec(p, perf_score=None):
    """Convert player dict to auction feature vector."""
    return [
        float(p.get("Age", p.get("age", 28))),
        float(p.get("Matches", p.get("matches", 0))),
        float(p.get("Runs", p.get("runs", 0))),
        float(p.get("Batting_Avg", p.get("batting_avg", 25))),
        float(p.get("Strike_Rate", p.get("strike_rate", 120))),
        float(p.get("Wickets", p.get("wickets", 0))),
        float(p.get("Economy", p.get("economy", 8))),
        float(p.get("Fitness_Score", p.get("fitness_score", 75))),
        float(p.get("Recent_Form", p.get("recent_form", 70))),
        float(p.get("Injury_Count", p.get("injury_count", 0))),
        float(p.get("IPL_Seasons", p.get("ipl_seasons", 1))),
        float(ROLE_MAP.get(p.get("Role", p.get("role", "Batsman")), 0)),
        1.0 if p.get("Nationality", p.get("nationality", "Indian")) == "Indian" else 0.0,
        float(perf_score or p.get("Performance_Score", p.get("performance_score", 70))),
    ]

def team_to_match_vec(team_a, team_b):
    """Build difference feature vector for match prediction."""
    sa = TEAM_STATS.get(team_a, {})
    sb = TEAM_STATS.get(team_b, {})
    def g(d, k, default=0): return float(d.get(k, default))
    return [
        g(sa,"avg_score",75) - g(sb,"avg_score",75),
        g(sa,"bat_avg",25)   - g(sb,"bat_avg",25),
        g(sa,"strike_rate",120) - g(sb,"strike_rate",120),
        g(sa,"wickets_avg",10) - g(sb,"wickets_avg",10),
        g(sb,"economy_avg",8) - g(sa,"economy_avg",8),
        g(sa,"fitness",80)   - g(sb,"fitness",80),
        g(sa,"form",80)      - g(sb,"form",80),
    ]

# ── Health ────────────────────────────────────────────────────────────────────
@app.route("/ml/health")
def health():
    return jsonify({"status": "ok", "models": ["performance","auction","match"], "teams": list(TEAM_STATS.keys())})

# ── Predict performance score ─────────────────────────────────────────────────
@app.route("/ml/predict-score", methods=["POST"])
def predict_score():
    try:
        p = request.json
        vec = np.array([player_to_perf_vec(p)])
        vec_sc = SCALER_PERF.transform(vec)
        score = float(MODEL_PERF.predict(vec_sc)[0])
        score = round(min(99, max(40, score)), 1)
        return jsonify({"predicted_score": score, "model": "RandomForest", "r2": 0.993})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# ── Predict auction price ─────────────────────────────────────────────────────
@app.route("/ml/predict-auction", methods=["POST"])
def predict_auction():
    try:
        p = request.json
        # First predict performance score
        vec_p = np.array([player_to_perf_vec(p)])
        vec_p_sc = SCALER_PERF.transform(vec_p)
        perf_score = float(MODEL_PERF.predict(vec_p_sc)[0])

        vec_a = np.array([player_to_auction_vec(p, perf_score)])
        vec_a_sc = SCALER_AUCTION.transform(vec_a)
        price = float(MODEL_AUCTION.predict(vec_a_sc)[0])
        price = round(max(0.5, min(20.0, price)), 1)

        tier = "Elite" if price >= 15 else "Top" if price >= 8 else "Mid" if price >= 3 else "Base"
        return jsonify({
            "player": p.get("name", p.get("Player_Name", "Unknown")),
            "predicted_price_cr": price,
            "tier": tier,
            "predicted_score": round(perf_score, 1),
            "model": "GradientBoosting",
            "r2": 0.937,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# ── Predict match winner ──────────────────────────────────────────────────────
@app.route("/ml/predict-match", methods=["POST"])
def predict_match():
    try:
        data = request.json
        team_a = data.get("team_a", "")
        team_b = data.get("team_b", "")
        venue  = data.get("venue", "neutral")

        if team_a not in TEAM_STATS or team_b not in TEAM_STATS:
            return jsonify({"error": f"Unknown team(s). Available: {list(TEAM_STATS.keys())}"}), 400

        vec = np.array([team_to_match_vec(team_a, team_b)])

        # Venue adjustments (modify team strength diff)
        SPIN_TEAMS = ["Chennai Super Kings", "Rajasthan Royals", "Mumbai Indians"]
        PACE_TEAMS = ["Gujarat Titans", "Sunrisers Hyderabad", "Kolkata Knight Riders"]
        if venue == "home-a":   vec[0][0] += 3
        if venue == "home-b":   vec[0][0] -= 3
        if venue == "spin"  and team_a in SPIN_TEAMS: vec[0][0] += 2
        if venue == "spin"  and team_b in SPIN_TEAMS: vec[0][0] -= 2
        if venue == "pace"  and team_a in PACE_TEAMS: vec[0][0] += 2
        if venue == "pace"  and team_b in PACE_TEAMS: vec[0][0] -= 2

        vec_sc = SCALER_MATCH.transform(vec)
        proba  = MODEL_MATCH.predict_proba(vec_sc)[0]
        prob_a = round(float(proba[1]) * 100, 1)
        prob_b = round(100 - prob_a, 1)
        winner = team_a if prob_a > prob_b else team_b

        sa = TEAM_STATS[team_a]
        sb = TEAM_STATS[team_b]

        return jsonify({
            "team_a": team_a,
            "team_b": team_b,
            "venue": venue,
            "win_prob_a": prob_a,
            "win_prob_b": prob_b,
            "predicted_winner": winner,
            "confidence": round(max(prob_a, prob_b), 1),
            "model": "RandomForest",
            "accuracy": 0.778,
            "team_a_stats": {
                "avg_score": round(sa.get("avg_score", 0), 1),
                "bat_avg": round(sa.get("bat_avg", 0), 1),
                "strike_rate": round(sa.get("strike_rate", 0), 1),
                "wickets_avg": round(sa.get("wickets_avg", 0), 1),
                "economy_avg": round(sa.get("economy_avg", 0), 2),
                "fitness": round(sa.get("fitness", 0), 1),
                "form": round(sa.get("form", 0), 1),
            },
            "team_b_stats": {
                "avg_score": round(sb.get("avg_score", 0), 1),
                "bat_avg": round(sb.get("bat_avg", 0), 1),
                "strike_rate": round(sb.get("strike_rate", 0), 1),
                "wickets_avg": round(sb.get("wickets_avg", 0), 1),
                "economy_avg": round(sb.get("economy_avg", 0), 2),
                "fitness": round(sb.get("fitness", 0), 1),
                "form": round(sb.get("form", 0), 1),
            },
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 400

# ── Batch predict all players ─────────────────────────────────────────────────
@app.route("/ml/predict-all", methods=["POST"])
def predict_all():
    try:
        players = request.json  # list of player dicts
        results = []
        for p in players:
            vec_p = np.array([player_to_perf_vec(p)])
            vec_p_sc = SCALER_PERF.transform(vec_p)
            perf = float(MODEL_PERF.predict(vec_p_sc)[0])
            perf = round(min(99, max(40, perf)), 1)

            vec_a = np.array([player_to_auction_vec(p, perf)])
            vec_a_sc = SCALER_AUCTION.transform(vec_a)
            price = float(MODEL_AUCTION.predict(vec_a_sc)[0])
            price = round(max(0.5, min(20.0, price)), 1)

            tier = "Elite" if price >= 15 else "Top" if price >= 8 else "Mid" if price >= 3 else "Base"
            results.append({
                "player_id": p.get("player_id", p.get("Player_ID", "")),
                "name": p.get("name", p.get("Player_Name", "")),
                "ml_score": perf,
                "ml_price": price,
                "tier": tier,
            })
        return jsonify({"count": len(results), "predictions": results})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    print("🚀 ML Server starting on http://localhost:5001")
    app.run(host="0.0.0.0", port=5001, debug=False)
